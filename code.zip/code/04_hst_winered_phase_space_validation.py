#!/usr/bin/env python3
"""
04_hst_winered_phase_space_validation.py

publication-scale physical-upgrade module for the BH 140 multi-survey validation project.
Run this AFTER:
  1) 01_build_membership_catalog.py
  2) bh140_outer_validation_v4.py or 03_bootstrap_control_validation.py

Main goals
----------
A) HST/MGCS artificial-star completeness + mass-function module
   - Uses the Gaia--MGCS crossmatch produced by v3.
   - Accepts an official isochrone CSV and an artificial-star/completeness CSV.
   - Assigns masses in CMD space, applies completeness weights, and compares
     inner/outer mass-function slopes.
   - If required columns are missing, it writes a strict readiness audit and
     blocks the physical mass-function claim rather than overclaiming.

B) WINERED source-level coordinate/RV crossmatch
   - Reads the extracted WINERED table from v3, or a user-supplied cleaned CSV.
   - Cleans RA/Dec/RV columns, crossmatches to Gaia members, and summarizes
     systemic RV and optional metallicity.
   - If coordinates are incomplete/NaN, it writes a clear verification failure.

C) Monte Carlo phase-space/orbit module
   - Always computes Astropy Galactocentric Monte Carlo phase-space summaries.
   - Optionally performs galpy orbit integrations if galpy is installed and
     --integrate-orbit is passed.
   - If galpy is not installed, it does not fail: it writes an orbit-readiness
     table and preserves the phase-space MC results.

Example Spyder/IPython commands
-------------------------------
# Readiness-only run, no isochrone/completeness:
%run "C:/Users/USER/Desktop/BH_140/04_hst_winered_phase_space_validation.py" --outdir "C:/Users/USER/Desktop/BH_140/results_BH140_multisurvey_validation_v3" --analyze

# Full HST MF run after supplying files:
%run "C:/Users/USER/Desktop/BH_140/04_hst_winered_phase_space_validation.py" --outdir "C:/Users/USER/Desktop/BH_140/results_BH140_multisurvey_validation_v3" --analyze --isochrone-csv "C:/Users/USER/Desktop/BH_140/isochrone_bh140.csv" --completeness-csv "C:/Users/USER/Desktop/BH_140/mgcs_ast_completeness.csv"

# Optional galpy orbit integration:
%run "C:/Users/USER/Desktop/BH_140/04_hst_winered_phase_space_validation.py" --outdir "C:/Users/USER/Desktop/BH_140/results_BH140_multisurvey_validation_v3" --analyze --integrate-orbit --mc-iter 1000
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import re
import site
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

_USER_SITE = site.getusersitepackages()
if _USER_SITE and _USER_SITE not in sys.path:
    sys.path.insert(0, _USER_SITE)

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.interpolate import interp1d
from scipy.stats import median_abs_deviation
from astropy import units as u
from astropy.coordinates import SkyCoord, Galactocentric
import matplotlib.pyplot as plt

LOGGER = logging.getLogger("BH140-VALIDATION-V6")


@dataclass
class Config:
    outdir: str = "results_BH140_multisurvey_validation_v3"
    ra_deg: float = 193.25125
    dec_deg: float = -67.174444
    distance_kpc: float = 4.81
    distance_err_kpc: float = 0.25
    pmra_masyr: float = -14.8685
    pmdec_masyr: float = 1.2164
    pm_err_masyr: float = 0.05
    rv_los_kms: float = 91.72
    rv_err_kms: float = 1.92
    solar_ro_kpc: float = 8.122
    solar_z_kpc: float = 0.0208

    isochrone_csv: str = ""
    completeness_csv: str = ""
    winered_csv: str = ""

    hst_match_arcsec: float = 0.50
    winered_match_arcsec: float = 1.00
    hst_inner_outer_split: float = 0.50
    mass_min: float = 0.45
    mass_max: float = 0.90
    mass_bins: int = 6
    mf_bootstrap: int = 1000
    random_seed: int = 42

    mc_iter: int = 5000
    save_mc_samples: bool = False
    integrate_orbit: bool = False
    orbit_tmax_gyr: float = 2.0
    orbit_nsteps: int = 1001
    orbit_mc_max: int = 300
    analyze: bool = False

    def paths(self) -> Dict[str, Path]:
        base = Path(self.outdir)
        v6 = base / "physical_validation"
        return {
            "base": base,
            "processed": base / "data" / "processed",
            "raw": base / "data" / "raw",
            "tables": base / "tables",
            "v6": v6,
            "v6_tables": v6 / "tables",
            "v6_figures": v6 / "figures",
        }


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def setup_dirs(cfg: Config) -> None:
    for p in cfg.paths().values():
        p.mkdir(parents=True, exist_ok=True)


def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    LOGGER.info("Saved %d rows to %s", len(df), path)


def save_json(obj: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")
    LOGGER.info("Saved JSON to %s", path)


def num(df: pd.DataFrame, col: str) -> np.ndarray:
    return pd.to_numeric(df[col], errors="coerce").to_numpy(float)


def find_col(columns: Iterable[str], patterns: List[str]) -> Optional[str]:
    cols = list(columns)
    lower_exact = {c.lower(): c for c in cols}
    for pat in patterns:
        p = pat.lower()
        if p in lower_exact:
            return lower_exact[p]
    for c in cols:
        cl = c.lower()
        for pat in patterns:
            if re.search(pat.lower(), cl):
                return c
    return None


def finite_mask(df: pd.DataFrame, cols: Iterable[str]) -> np.ndarray:
    m = np.ones(len(df), dtype=bool)
    for c in cols:
        if c not in df.columns:
            return np.zeros(len(df), dtype=bool)
        m &= np.isfinite(pd.to_numeric(df[c], errors="coerce").to_numpy(float))
    return m


def robust_sigma(x: np.ndarray) -> float:
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size < 2:
        return np.nan
    return 1.4826 * float(median_abs_deviation(x, nan_policy="omit"))


def tangent_offsets(ra: np.ndarray, dec: np.ndarray, ra0: float, dec0: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = (ra - ra0) * math.cos(math.radians(dec0))
    y = dec - dec0
    r = np.sqrt(x * x + y * y)
    return x, y, r


def angular_sep_arcsec(ra1: np.ndarray, dec1: np.ndarray, ra2: np.ndarray, dec2: np.ndarray) -> np.ndarray:
    c1 = SkyCoord(ra=np.asarray(ra1) * u.deg, dec=np.asarray(dec1) * u.deg, frame="icrs")
    c2 = SkyCoord(ra=np.asarray(ra2) * u.deg, dec=np.asarray(dec2) * u.deg, frame="icrs")
    return c1.separation(c2).arcsec


# ----------------------------
# Loading helpers
# ----------------------------

def load_gaia_members(cfg: Config) -> pd.DataFrame:
    p1 = cfg.paths()["processed"] / "gaia_primary_members.csv"
    p2 = cfg.paths()["processed"] / "gaia_dr3_with_membership.csv"
    if p1.exists():
        df = pd.read_csv(p1)
    elif p2.exists():
        df = pd.read_csv(p2)
        if "Pmem" in df.columns:
            df = df[pd.to_numeric(df["Pmem"], errors="coerce") >= 0.90].copy()
        elif "p_mem" in df.columns:
            df = df[pd.to_numeric(df["p_mem"], errors="coerce") >= 0.90].copy()
    else:
        raise FileNotFoundError("Could not find Gaia processed member table. Run v3 first.")
    for old, new in [("ra_deg", "ra"), ("dec_deg", "dec")]:
        if old in df.columns and new not in df.columns:
            df[new] = df[old]
    return df


def locate_hst_crossmatch(cfg: Config) -> Optional[Path]:
    processed = cfg.paths()["processed"]

    # Prefer merged Gaia--MGCS astro+phot table.
    priority_patterns = [
        "crossmatch_gaia_mgcs*_astro_phot.csv",
        "*mgcs*astro_phot*.csv",
        "crossmatch_gaia_mgcs*_phot*.csv",
    ]

    for pat in priority_patterns:
        preferred = [
            p for p in processed.glob(pat)
            if p.exists() and p.stat().st_size > 0
        ]
        if preferred:
            preferred.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            return preferred[0]

    candidates = list(processed.glob("crossmatch_gaia_mgcs*_astro.csv"))
    candidates += list(processed.glob("*mgcs*astro*.csv"))
    candidates = [p for p in candidates if p.exists() and p.stat().st_size > 0]

    if not candidates:
        return None

    candidates.sort(key=lambda p: p.stat().st_size, reverse=True)
    return candidates[0]


def load_hst_crossmatch(cfg: Config) -> Optional[pd.DataFrame]:
    p = locate_hst_crossmatch(cfg)
    if p is None:
        return None
    df = pd.read_csv(p)
    df.attrs["source_file"] = str(p)
    return df


def locate_winered_file(cfg: Config) -> Optional[Path]:
    if cfg.winered_csv:
        p = Path(cfg.winered_csv)
        return p if p.exists() else None
    p = cfg.paths()["raw"] / "winered_bh140_extracted_rows.csv"
    if p.exists():
        return p
    cand = list(cfg.paths()["raw"].glob("*winered*.csv"))
    return cand[0] if cand else None


# ----------------------------
# HST/MGCS MF module
# ----------------------------

def identify_cmd_columns(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    cols = list(df.columns)
    # Try common HST ACS/WFC optical filters first.
    f606 = find_col(cols, [r"^f606w$", r"f606", r"m606", r"mag606", r"vega606"])
    f814 = find_col(cols, [r"^f814w$", r"f814", r"m814", r"mag814", r"vega814"])
    f555 = find_col(cols, [r"f555", r"m555"])
    f438 = find_col(cols, [r"f438", r"m438"])
    gmag = find_col(cols, [r"phot_g_mean_mag", r"^g$", r"gmag", r"gaia_g"])
    bp = find_col(cols, [r"bp_rp", r"bp-rp", r"gbp.*grp", r"bp.*rp"])
    color = None
    mag = None
    color_label = None
    mag_label = None
    if f606 and f814:
        mag = f606
        color = "__F606W_minus_F814W__"
        color_label = f"{f606}-{f814}"
        mag_label = f606
    elif f555 and f814:
        mag = f555
        color = "__F555W_minus_F814W__"
        color_label = f"{f555}-{f814}"
        mag_label = f555
    elif gmag and bp:
        mag = gmag
        color = bp
        color_label = bp
        mag_label = gmag
    return {"mag_col": mag, "color_col": color, "f606": f606, "f814": f814, "f555": f555, "bp": bp, "mag_label": mag_label, "color_label": color_label}


def add_hst_cmd_columns(df: pd.DataFrame, cmd: Dict[str, Optional[str]]) -> pd.DataFrame:
    out = df.copy()
    if cmd["color_col"] == "__F606W_minus_F814W__" and cmd["f606"] and cmd["f814"]:
        out[cmd["color_col"]] = pd.to_numeric(out[cmd["f606"]], errors="coerce") - pd.to_numeric(out[cmd["f814"]], errors="coerce")
    if cmd["color_col"] == "__F555W_minus_F814W__" and cmd["f555"] and cmd["f814"]:
        out[cmd["color_col"]] = pd.to_numeric(out[cmd["f555"]], errors="coerce") - pd.to_numeric(out[cmd["f814"]], errors="coerce")
    return out


def identify_isochrone_columns(iso: pd.DataFrame, target_cmd: Dict[str, Optional[str]]) -> Dict[str, Optional[str]]:
    cols = list(iso.columns)
    mass = find_col(cols, [r"^mass$", r"mini", r"m_ini", r"mact", r"star_mass", r"mass_msun"])
    # Prefer target filters if present.
    f606 = find_col(cols, [r"f606", r"acs.*606", r"wfc.*606", r"mag606", r"m606"])
    f814 = find_col(cols, [r"f814", r"acs.*814", r"wfc.*814", r"mag814", r"m814"])
    f555 = find_col(cols, [r"f555", r"m555"])
    gmag = find_col(cols, [r"phot_g", r"gaia.*g", r"^g$", r"gmag"])
    color = find_col(cols, [r"color", r"bp_rp", r"bp-rp", r"f606.*f814", r"f555.*f814"])
    mag = None
    iso_color_col = None
    if target_cmd.get("f606") and target_cmd.get("f814") and f606 and f814:
        mag = f606
        iso_color_col = "__ISO_F606W_minus_F814W__"
    elif target_cmd.get("f555") and target_cmd.get("f814") and f555 and f814:
        mag = f555
        iso_color_col = "__ISO_F555W_minus_F814W__"
    elif gmag and color:
        mag = gmag
        iso_color_col = color
    else:
        mag = find_col(cols, [r"mag", r"magnitude", r"f606", r"f814", r"gmag"])
        iso_color_col = color
    return {"mass_col": mass, "mag_col": mag, "color_col": iso_color_col, "f606": f606, "f814": f814, "f555": f555}


def add_iso_cmd_columns(iso: pd.DataFrame, icols: Dict[str, Optional[str]]) -> pd.DataFrame:
    out = iso.copy()
    if icols["color_col"] == "__ISO_F606W_minus_F814W__" and icols["f606"] and icols["f814"]:
        out[icols["color_col"]] = pd.to_numeric(out[icols["f606"]], errors="coerce") - pd.to_numeric(out[icols["f814"]], errors="coerce")
    if icols["color_col"] == "__ISO_F555W_minus_F814W__" and icols["f555"] and icols["f814"]:
        out[icols["color_col"]] = pd.to_numeric(out[icols["f555"]], errors="coerce") - pd.to_numeric(out[icols["f814"]], errors="coerce")
    return out


def assign_mass_from_isochrone(hst: pd.DataFrame, iso: pd.DataFrame, cmd_cols: Dict[str, Optional[str]], icols: Dict[str, Optional[str]], cfg: Config) -> pd.DataFrame:
    hst = add_hst_cmd_columns(hst, cmd_cols)
    iso = add_iso_cmd_columns(iso, icols)
    mag_col = cmd_cols["mag_col"]
    color_col = cmd_cols["color_col"]
    iso_mag = icols["mag_col"]
    iso_color = icols["color_col"]
    mass_col = icols["mass_col"]
    if not all([mag_col, color_col, iso_mag, iso_color, mass_col]):
        raise ValueError("Missing CMD or isochrone columns for mass assignment")

    hmask = finite_mask(hst, [mag_col, color_col])
    imask = finite_mask(iso, [iso_mag, iso_color, mass_col])
    iso2 = iso.loc[imask].copy()
    iso2 = iso2[(pd.to_numeric(iso2[mass_col], errors="coerce") >= cfg.mass_min) &
                (pd.to_numeric(iso2[mass_col], errors="coerce") <= cfg.mass_max)].copy()
    if len(iso2) < 5:
        raise ValueError("Too few isochrone points after mass range cut")

    # Robust scaling for nearest-neighbour CMD matching.
    hmag = pd.to_numeric(hst.loc[hmask, mag_col], errors="coerce").to_numpy(float)
    hcol = pd.to_numeric(hst.loc[hmask, color_col], errors="coerce").to_numpy(float)
    imag = pd.to_numeric(iso2[iso_mag], errors="coerce").to_numpy(float)
    icol = pd.to_numeric(iso2[iso_color], errors="coerce").to_numpy(float)
    smag = np.nanstd(hmag) if np.nanstd(hmag) > 0 else 1.0
    scol = np.nanstd(hcol) if np.nanstd(hcol) > 0 else 1.0
    tree = cKDTree(np.column_stack([icol / scol, imag / smag]))
    dist, idx = tree.query(np.column_stack([hcol / scol, hmag / smag]), k=1)

    out = hst.copy()
    out["mass_iso_msun"] = np.nan
    out["cmd_match_distance"] = np.nan
    masses = pd.to_numeric(iso2.iloc[idx][mass_col], errors="coerce").to_numpy(float)
    out.loc[hmask, "mass_iso_msun"] = masses
    out.loc[hmask, "cmd_match_distance"] = dist
    out.attrs["cmd_mag_col"] = mag_col
    out.attrs["cmd_color_col"] = color_col
    return out


def load_completeness(cfg: Config) -> Optional[pd.DataFrame]:
    if not cfg.completeness_csv:
        return None
    p = Path(cfg.completeness_csv)
    if not p.exists():
        raise FileNotFoundError(f"Completeness CSV not found: {p}")
    return pd.read_csv(p)


def completeness_weights(df: pd.DataFrame, comp: Optional[pd.DataFrame], mag_col: str) -> np.ndarray:
    n = len(df)
    if comp is None or len(comp) == 0:
        return np.ones(n)
    cols = list(comp.columns)
    c_mag = find_col(cols, [r"^mag$", r"magnitude", r"f606", r"f814", r"gmag", r"input_mag"])
    c_comp = find_col(cols, [r"completeness", r"comp", r"recovery", r"frac", r"p_rec", r"c$", r"ratio"])
    if not c_mag or not c_comp:
        LOGGER.warning("Completeness CSV does not expose mag/completeness columns; using unit weights")
        return np.ones(n)
    x = pd.to_numeric(comp[c_mag], errors="coerce").to_numpy(float)
    y = pd.to_numeric(comp[c_comp], errors="coerce").to_numpy(float)
    m = np.isfinite(x) & np.isfinite(y) & (y > 0) & (y <= 1.5)
    if m.sum() < 3:
        LOGGER.warning("Completeness CSV has too few valid rows; using unit weights")
        return np.ones(n)
    order = np.argsort(x[m])
    f = interp1d(x[m][order], np.clip(y[m][order], 0.05, 1.0), bounds_error=False,
                 fill_value=(np.clip(y[m][order][0], 0.05, 1.0), np.clip(y[m][order][-1], 0.05, 1.0)))
    mag = pd.to_numeric(df[mag_col], errors="coerce").to_numpy(float)
    c = np.asarray(f(mag), float)
    c[~np.isfinite(c)] = 1.0
    return 1.0 / np.clip(c, 0.05, 1.0)


def fit_mass_function_slope(mass: np.ndarray, weights: np.ndarray, cfg: Config) -> Tuple[float, float, pd.DataFrame]:
    mass = np.asarray(mass, float)
    weights = np.asarray(weights, float)
    m = np.isfinite(mass) & np.isfinite(weights) & (mass >= cfg.mass_min) & (mass <= cfg.mass_max) & (weights > 0)
    mass = mass[m]
    weights = weights[m]
    bins = np.linspace(cfg.mass_min, cfg.mass_max, cfg.mass_bins + 1)
    counts, edges = np.histogram(mass, bins=bins, weights=weights)
    raw_counts, _ = np.histogram(mass, bins=bins)
    centers = 0.5 * (edges[:-1] + edges[1:])
    widths = np.diff(edges)
    dndm = counts / widths
    good = (raw_counts >= 3) & (dndm > 0) & np.isfinite(dndm)
    if good.sum() < 3:
        alpha = np.nan
        alpha_err = np.nan
    else:
        x = np.log10(centers[good])
        y = np.log10(dndm[good])
        coeff = np.polyfit(x, y, 1)
        # dN/dm ∝ m^{-alpha}; slope in log-log = -alpha.
        alpha = -float(coeff[0])
        # approximate uncertainty from residuals
        yfit = np.polyval(coeff, x)
        if len(x) > 2:
            s = np.sqrt(np.sum((y - yfit) ** 2) / (len(x) - 2))
            sx = np.sqrt(np.sum((x - x.mean()) ** 2))
            alpha_err = float(s / sx) if sx > 0 else np.nan
        else:
            alpha_err = np.nan
    table = pd.DataFrame({
        "mass_lo": edges[:-1], "mass_hi": edges[1:], "mass_mid": centers,
        "weighted_count": counts, "raw_count": raw_counts, "dndm": dndm,
    })
    return alpha, alpha_err, table


def bootstrap_alpha(mass: np.ndarray, weights: np.ndarray, cfg: Config, rng: np.random.Generator) -> np.ndarray:
    mass = np.asarray(mass, float)
    weights = np.asarray(weights, float)
    m = np.isfinite(mass) & np.isfinite(weights) & (mass >= cfg.mass_min) & (mass <= cfg.mass_max) & (weights > 0)
    mass = mass[m]
    weights = weights[m]
    if len(mass) < 20:
        return np.array([np.nan] * cfg.mf_bootstrap)
    alphas = []
    for _ in range(cfg.mf_bootstrap):
        idx = rng.integers(0, len(mass), len(mass))
        a, _, _ = fit_mass_function_slope(mass[idx], weights[idx], cfg)
        alphas.append(a)
    return np.asarray(alphas, float)


def run_hst_mass_function(cfg: Config) -> Dict[str, object]:
    paths = cfg.paths()
    rng = np.random.default_rng(cfg.random_seed)
    hst = load_hst_crossmatch(cfg)
    status_rows = []
    if hst is None or len(hst) == 0:
        status = {"hst_status": "missing_crossmatch", "physical_mf_gate": "blocked_missing_hst_crossmatch"}
        save_csv(pd.DataFrame([status]), paths["v6_tables"] / "BH140_v6_hst_mass_function_status.csv")
        return status

    hst_file = hst.attrs.get("source_file", "unknown")
    cmd_cols = identify_cmd_columns(hst)
    hst = add_hst_cmd_columns(hst, cmd_cols)
    status_rows.append({"check": "HST/MGCS crossmatch", "status": "available", "value": len(hst), "note": hst_file})
    status_rows.append({"check": "CMD mag column", "status": "available" if cmd_cols["mag_col"] else "missing", "value": cmd_cols["mag_col"], "note": "Detected magnitude column"})
    status_rows.append({"check": "CMD color column", "status": "available" if cmd_cols["color_col"] else "missing", "value": cmd_cols["color_col"], "note": cmd_cols.get("color_label")})

    if not cfg.isochrone_csv:
        status_rows.append({"check": "Official isochrone", "status": "missing", "value": "", "note": "Required for physical mass-function slope"})
    if not cfg.completeness_csv:
        status_rows.append({"check": "Artificial-star completeness", "status": "missing", "value": "", "note": "Required for completeness-corrected physical MF"})

    if not (cmd_cols["mag_col"] and cmd_cols["color_col"] and cfg.isochrone_csv and cfg.completeness_csv):
        gate = "blocked_missing_isochrone_completeness_or_cmd_columns"
        status_rows.append({"check": "Physical MF gate", "status": gate, "value": "", "note": "Use as HST readiness only"})
        save_csv(pd.DataFrame(status_rows), paths["v6_tables"] / "BH140_v6_hst_mass_function_status.csv")
        return {"hst_n": int(len(hst)), "physical_mf_gate": gate, "cmd_columns": cmd_cols}

    iso = pd.read_csv(cfg.isochrone_csv)
    comp = load_completeness(cfg)
    icols = identify_isochrone_columns(iso, cmd_cols)
    status_rows.append({"check": "Isochrone mass column", "status": "available" if icols["mass_col"] else "missing", "value": icols["mass_col"], "note": cfg.isochrone_csv})
    status_rows.append({"check": "Isochrone mag/color columns", "status": "available" if icols["mag_col"] and icols["color_col"] else "missing", "value": f"{icols['mag_col']} / {icols['color_col']}", "note": "auto-detected"})
    if not (icols["mass_col"] and icols["mag_col"] and icols["color_col"]):
        gate = "blocked_bad_isochrone_columns"
        status_rows.append({"check": "Physical MF gate", "status": gate, "value": "", "note": "Check isochrone CSV column names"})
        save_csv(pd.DataFrame(status_rows), paths["v6_tables"] / "BH140_v6_hst_mass_function_status.csv")
        return {"hst_n": int(len(hst)), "physical_mf_gate": gate, "cmd_columns": cmd_cols, "iso_columns": icols}

    hstm = assign_mass_from_isochrone(hst, iso, cmd_cols, icols, cfg)
    mag_col = cmd_cols["mag_col"]
    hstm["comp_weight"] = completeness_weights(hstm, comp, mag_col)
    # Radius column in crossmatch may have target Gaia radius. Find or compute.
    rcol = find_col(hstm.columns, [r"r_deg$", r"radius", r"Rdeg", r"sep_deg", r"r_projected"])
    if rcol is None and {"ra", "dec"}.issubset(set(hstm.columns)):
        _, _, r = tangent_offsets(num(hstm, "ra"), num(hstm, "dec"), cfg.ra_deg, cfg.dec_deg)
        hstm["r_deg_hst"] = r
        rcol = "r_deg_hst"
    elif rcol is None:
        # Fallback: no reliable split, use half sample index sorted by CMD distance.
        hstm["r_deg_hst"] = np.nan
        rcol = "r_deg_hst"

    valid = np.isfinite(pd.to_numeric(hstm["mass_iso_msun"], errors="coerce").to_numpy(float))
    if rcol and np.isfinite(pd.to_numeric(hstm[rcol], errors="coerce").to_numpy(float)).sum() >= 20:
        r = pd.to_numeric(hstm[rcol], errors="coerce").to_numpy(float)
        split = np.nanquantile(r, cfg.hst_inner_outer_split)
        inner = valid & np.isfinite(r) & (r <= split)
        outer = valid & np.isfinite(r) & (r > split)
    else:
        split = np.nan
        idx = np.where(valid)[0]
        half = len(idx) // 2
        inner = np.zeros(len(hstm), dtype=bool); outer = np.zeros(len(hstm), dtype=bool)
        inner[idx[:half]] = True; outer[idx[half:]] = True

    a_in, ae_in, bins_in = fit_mass_function_slope(hstm.loc[inner, "mass_iso_msun"], hstm.loc[inner, "comp_weight"], cfg)
    a_out, ae_out, bins_out = fit_mass_function_slope(hstm.loc[outer, "mass_iso_msun"], hstm.loc[outer, "comp_weight"], cfg)
    b_in = bootstrap_alpha(hstm.loc[inner, "mass_iso_msun"], hstm.loc[inner, "comp_weight"], cfg, rng)
    b_out = bootstrap_alpha(hstm.loc[outer, "mass_iso_msun"], hstm.loc[outer, "comp_weight"], cfg, rng)
    delta = a_out - a_in
    delta_boot = b_out - b_in
    delta_err = float(np.nanstd(delta_boot)) if np.isfinite(delta_boot).sum() > 10 else np.nan
    p_delta_le0 = float(np.nanmean(delta_boot <= 0)) if np.isfinite(delta_boot).sum() > 10 else np.nan

    bins_in["radial_bin"] = "inner"
    bins_out["radial_bin"] = "outer"
    bins = pd.concat([bins_in, bins_out], ignore_index=True)

    summary = {
        "hst_n": int(len(hst)),
        "valid_mass_n": int(valid.sum()),
        "inner_n": int(inner.sum()),
        "outer_n": int(outer.sum()),
        "split_radius_deg_or_nan": float(split) if np.isfinite(split) else np.nan,
        "alpha_inner": a_in,
        "alpha_inner_err_fit": ae_in,
        "alpha_outer": a_out,
        "alpha_outer_err_fit": ae_out,
        "delta_alpha_outer_minus_inner": delta,
        "delta_alpha_boot_err": delta_err,
        "p_delta_alpha_le0": p_delta_le0,
        "physical_mf_gate": "physical_MF_computed_with_user_isochrone_and_completeness",
        "cmd_mag_col": cmd_cols["mag_col"],
        "cmd_color_col": cmd_cols["color_col"],
        "iso_mass_col": icols["mass_col"],
        "iso_mag_col": icols["mag_col"],
        "iso_color_col": icols["color_col"],
    }
    status_rows.append({"check": "Physical MF gate", "status": summary["physical_mf_gate"], "value": summary["valid_mass_n"], "note": "Completeness-corrected MF computed"})

    save_csv(hstm, paths["v6_tables"] / "BH140_v6_hst_crossmatch_with_mass.csv")
    save_csv(bins, paths["v6_tables"] / "BH140_v6_hst_mass_function_bins.csv")
    save_csv(pd.DataFrame([summary]), paths["v6_tables"] / "BH140_v6_hst_mass_function_summary.csv")
    save_csv(pd.DataFrame(status_rows), paths["v6_tables"] / "BH140_v6_hst_mass_function_status.csv")

    # Plot MF bins.
    try:
        fig, ax = plt.subplots(figsize=(8, 6))
        for lab, d in bins.groupby("radial_bin"):
            ax.plot(d["mass_mid"], d["dndm"], marker="o", label=lab)
        ax.set_yscale("log")
        ax.set_xlabel("Mass [Msun]")
        ax.set_ylabel("Completeness-weighted dN/dm")
        ax.set_title("BH 140 HST/MGCS completeness-corrected MF diagnostic")
        ax.legend()
        fig.tight_layout()
        fig.savefig(paths["v6_figures"] / "BH140_v6_hst_mass_function.png", dpi=180)
        plt.close(fig)
    except Exception as e:
        LOGGER.warning("Could not save HST MF plot: %s", e)
    return summary


# ----------------------------
# WINERED crossmatch + RV
# ----------------------------

def clean_numeric_from_string(x) -> float:
    if pd.isna(x):
        return np.nan
    if isinstance(x, (int, float, np.floating)):
        return float(x)
    s = str(x)
    # Remove LaTeX and unicode clutter, keep first signed float.
    s = s.replace("−", "-")
    m = re.search(r"[-+]?\d+(?:\.\d+)?", s)
    return float(m.group(0)) if m else np.nan


def normalize_coord_token(x) -> str:
    """Normalize HTML/LaTeX coordinate tokens from arXiv tables.

    The WINERED HTML table uses unicode minus signs and sometimes produces
    strings such as "−-67.104256" after table extraction.  This helper turns
    these into ordinary parsable coordinate tokens such as "-67.104256".
    """
    if pd.isna(x):
        return ""
    s = str(x).strip()
    # remove zero-width and non-breaking spaces
    for z in ["\u200b", "\u200c", "\u200d", "\xa0"]:
        s = s.replace(z, "")
    # normalize unicode dashes/minus signs
    for m in ["−", "–", "—", "‑"]:
        s = s.replace(m, "-")
    # remove simple LaTeX leftovers
    s = s.replace("\\", "")
    s = s.replace("{", "").replace("}", "")
    s = s.replace("\pm", "").replace("\sim", "")
    s = re.sub(r"\s+", "", s)
    # collapse multiple leading sign characters to one sign
    m = re.match(r"^([+\-]+)(.*)$", s)
    if m:
        signs, rest = m.groups()
        s = ("-" if "-" in signs else "+") + rest
    return s


def parse_coord_series(ra_s: pd.Series, dec_s: pd.Series) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    ra_out = np.full(len(ra_s), np.nan)
    dec_out = np.full(len(dec_s), np.nan)
    valid = np.zeros(len(ra_s), dtype=bool)
    for i, (ra0, de0) in enumerate(zip(ra_s, dec_s)):
        ra_txt = normalize_coord_token(ra0)
        de_txt = normalize_coord_token(de0)
        if not ra_txt or not de_txt:
            continue
        c = None
        # Decimal degrees first.
        try:
            ra_f = float(ra_txt)
            de_f = float(de_txt)
            c = SkyCoord(ra=ra_f * u.deg, dec=de_f * u.deg, frame="icrs")
        except Exception:
            pass
        if c is None:
            # Sexagesimal RA + sexagesimal/degree Dec.
            try:
                c = SkyCoord(ra_txt, de_txt, unit=(u.hourangle, u.deg), frame="icrs")
            except Exception:
                try:
                    c = SkyCoord(f"{ra_txt} {de_txt}", unit=(u.hourangle, u.deg), frame="icrs")
                except Exception:
                    continue
        ra_out[i] = c.ra.deg
        dec_out[i] = c.dec.deg
        valid[i] = np.isfinite(ra_out[i]) and np.isfinite(dec_out[i])
    return ra_out, dec_out, valid


def run_winered_crossmatch_orbit(cfg: Config, gaia: pd.DataFrame) -> Dict[str, object]:
    paths = cfg.paths()
    p = locate_winered_file(cfg)
    status = {
        "winered_status": "missing",
        "winered_rows": 0,
        "winered_file": str(p) if p else "",
        "winered_crossmatch_n": 0,
        "rv_median_kms": np.nan,
        "rv_robust_sigma_kms": np.nan,
        "feh_median": np.nan,
        "winered_gate": "blocked_missing_winered_file",
    }
    if p is None:
        save_csv(pd.DataFrame([status]), paths["v6_tables"] / "BH140_v6_winered_crossmatch_summary.csv")
        return status
    w = pd.read_csv(p)
    status.update({"winered_status": "available", "winered_rows": int(len(w)), "winered_gate": "available_not_verified"})
    cols = list(w.columns)
    ra_col = find_col(cols, [r"^ra$", r"raj2000", r"ra_deg", r"alpha"])
    dec_col = find_col(cols, [r"^dec$", r"^de$", r"dej2000", r"dec_deg", r"delta"])
    # Prefer source-level WINERED RVs over cluster-mean RV columns.
    rv_col = find_col(cols, [r"^winered\s*rvs?$", r"winered.*rv", r"rv", r"radial", r"vlos", r"v_los", r"velocity"])
    feh_col = find_col(cols, [r"feh", r"\[fe/h\]", r"metal", r"mh"])
    status.update({"ra_col": ra_col or "not_found", "dec_col": dec_col or "not_found", "rv_col": rv_col or "not_found", "feh_col": feh_col or "not_found"})

    if not (ra_col and dec_col):
        status["winered_gate"] = "blocked_missing_coordinate_columns"
        save_csv(pd.DataFrame([status]), paths["v6_tables"] / "BH140_v6_winered_crossmatch_summary.csv")
        save_csv(w, paths["v6_tables"] / "BH140_v6_winered_cleaned_rows.csv")
        return status
    ra, dec, valid = parse_coord_series(w[ra_col], w[dec_col])
    w["ra_clean_deg"] = ra
    w["dec_clean_deg"] = dec
    if rv_col:
        w["rv_clean_kms"] = [clean_numeric_from_string(x) for x in w[rv_col]]
    else:
        w["rv_clean_kms"] = np.nan
    if feh_col:
        w["feh_clean"] = [clean_numeric_from_string(x) for x in w[feh_col]]
    else:
        w["feh_clean"] = np.nan

    # Identify source-level rows. Cluster-summary/orbit rows in the HTML table
    # should not be counted as source-level crossmatch detections.
    id_col = find_col(cols, [r"id\s*gaia", r"gaia\s*dr3", r"source_id", r"sourceid"])
    j_col = find_col(cols, [r"^j\s*band$", r"jmag", r"phot_j"])
    source_level = np.zeros(len(w), dtype=bool)
    if id_col:
        source_level |= pd.to_numeric(w[id_col], errors="coerce").notna().to_numpy()
    if j_col:
        source_level |= pd.to_numeric(w[j_col], errors="coerce").notna().to_numpy()
    if "Date of Observation" in w.columns:
        source_level |= w["Date of Observation"].notna().to_numpy()
    w["winered_source_level"] = source_level

    valid &= source_level & np.isfinite(w["ra_clean_deg"].to_numpy(float)) & np.isfinite(w["dec_clean_deg"].to_numpy(float))
    if valid.sum() == 0:
        status["winered_gate"] = "blocked_no_valid_coordinates_after_cleaning"
        save_csv(pd.DataFrame([status]), paths["v6_tables"] / "BH140_v6_winered_crossmatch_summary.csv")
        save_csv(w, paths["v6_tables"] / "BH140_v6_winered_cleaned_rows.csv")
        return status

    # Gaia coordinates.
    if not {"ra", "dec"}.issubset(gaia.columns):
        status["winered_gate"] = "blocked_missing_gaia_coordinates"
        save_csv(pd.DataFrame([status]), paths["v6_tables"] / "BH140_v6_winered_crossmatch_summary.csv")
        save_csv(w, paths["v6_tables"] / "BH140_v6_winered_cleaned_rows.csv")
        return status
    gm = finite_mask(gaia, ["ra", "dec"])
    g = gaia.loc[gm].copy().reset_index(drop=True)
    c_g = SkyCoord(ra=num(g, "ra") * u.deg, dec=num(g, "dec") * u.deg, frame="icrs")
    c_w = SkyCoord(ra=w.loc[valid, "ra_clean_deg"].to_numpy(float) * u.deg,
                   dec=w.loc[valid, "dec_clean_deg"].to_numpy(float) * u.deg, frame="icrs")
    idx, sep2d, _ = c_w.match_to_catalog_sky(c_g)
    w_valid = w.loc[valid].copy().reset_index(drop=True)
    w_valid["gaia_match_sep_arcsec"] = sep2d.arcsec
    matched = w_valid[sep2d.arcsec <= cfg.winered_match_arcsec].copy()
    if len(matched) > 0:
        gmatch = g.iloc[idx[sep2d.arcsec <= cfg.winered_match_arcsec]].reset_index(drop=True)
        for col in ["source_id", "ra", "dec", "pmra", "pmdec", "parallax", "Pmem", "p_mem", "q"]:
            if col in gmatch.columns:
                matched[f"gaia_{col}"] = gmatch[col].to_numpy()

    rv_all = pd.to_numeric(w["rv_clean_kms"], errors="coerce").to_numpy(float)
    src = w.get("winered_source_level", pd.Series([False] * len(w))).to_numpy(bool)
    rv = rv_all[src & np.isfinite(rv_all)]
    # Fallback to any RV values, e.g. a cluster-mean row, for phase-space context.
    if rv.size == 0:
        rv = rv_all[np.isfinite(rv_all)]
    feh_all = pd.to_numeric(w["feh_clean"], errors="coerce").to_numpy(float)
    feh = feh_all[src & np.isfinite(feh_all)]
    if feh.size == 0:
        feh = feh_all[np.isfinite(feh_all)]
    status.update({
        "winered_valid_coord_n": int(valid.sum()),
        "winered_crossmatch_n": int(len(matched)),
        "rv_available_n": int(rv.size),
        "rv_median_kms": float(np.nanmedian(rv)) if rv.size else np.nan,
        "rv_robust_sigma_kms": robust_sigma(rv) if rv.size > 1 else np.nan,
        "feh_available_n": int(feh.size),
        "feh_median": float(np.nanmedian(feh)) if feh.size else np.nan,
        "winered_gate": "source_level_crossmatch_verified" if len(matched) > 0 else "rv_table_available_but_no_gaia_source_match",
    })
    save_csv(w, paths["v6_tables"] / "BH140_v6_winered_cleaned_rows.csv")
    save_csv(matched, paths["v6_tables"] / "BH140_v6_winered_gaia_crossmatch.csv")
    save_csv(pd.DataFrame([status]), paths["v6_tables"] / "BH140_v6_winered_crossmatch_summary.csv")
    return status


# ----------------------------
# Monte Carlo phase-space/orbit
# ----------------------------

def get_summary_value(cfg: Config, key: str, default: float) -> float:
    for p in [cfg.paths()["base"] / "BH140_summary.json", cfg.paths()["tables"] / "BH140_summary_table.csv"]:
        try:
            if p.exists() and p.suffix == ".json":
                obj = json.loads(p.read_text(encoding="utf-8"))
                if key in obj and pd.notna(obj[key]):
                    return float(obj[key])
            if p.exists() and p.suffix == ".csv":
                df = pd.read_csv(p)
                if key in df.columns and len(df):
                    return float(df[key].iloc[0])
        except Exception:
            pass
    return default


def run_phase_space_mc(cfg: Config, winered_status: Dict[str, object]) -> Dict[str, object]:
    paths = cfg.paths()
    rng = np.random.default_rng(cfg.random_seed)
    pmra0 = get_summary_value(cfg, "pmra_med", cfg.pmra_masyr)
    pmdec0 = get_summary_value(cfg, "pmdec_med", cfg.pmdec_masyr)
    # Prefer source-level WINERED RV if available; otherwise adopted RV.
    rv_med = winered_status.get("rv_median_kms", np.nan)
    rv0 = float(rv_med) if pd.notna(rv_med) and np.isfinite(rv_med) else cfg.rv_los_kms
    rv_sig = winered_status.get("rv_robust_sigma_kms", np.nan)
    rv_err = float(rv_sig) if pd.notna(rv_sig) and np.isfinite(rv_sig) and rv_sig > 0 else cfg.rv_err_kms

    n = cfg.mc_iter
    dist = rng.normal(cfg.distance_kpc, cfg.distance_err_kpc, n)
    pmra = rng.normal(pmra0, cfg.pm_err_masyr, n)
    pmdec = rng.normal(pmdec0, cfg.pm_err_masyr, n)
    rv = rng.normal(rv0, rv_err, n)
    m = (dist > 0) & np.isfinite(dist) & np.isfinite(pmra) & np.isfinite(pmdec) & np.isfinite(rv)
    dist, pmra, pmdec, rv = dist[m], pmra[m], pmdec[m], rv[m]

    c = SkyCoord(
        ra=np.full_like(dist, cfg.ra_deg) * u.deg,
        dec=np.full_like(dist, cfg.dec_deg) * u.deg,
        distance=dist * u.kpc,
        pm_ra_cosdec=pmra * u.mas / u.yr,
        pm_dec=pmdec * u.mas / u.yr,
        radial_velocity=rv * u.km / u.s,
        frame="icrs",
    )
    gc_frame = Galactocentric(galcen_distance=cfg.solar_ro_kpc * u.kpc, z_sun=cfg.solar_z_kpc * u.kpc)
    g = c.transform_to(gc_frame)
    x = g.x.to_value(u.kpc); y = g.y.to_value(u.kpc); z = g.z.to_value(u.kpc)
    vx = g.v_x.to_value(u.km / u.s); vy = g.v_y.to_value(u.km / u.s); vz = g.v_z.to_value(u.km / u.s)
    R = np.sqrt(x * x + y * y)
    r3 = np.sqrt(x * x + y * y + z * z)
    Lz = x * vy - y * vx
    vtot = np.sqrt(vx * vx + vy * vy + vz * vz)
    # Cylindrical radial/tangential velocities in Galactocentric frame.
    vR = (x * vx + y * vy) / np.maximum(R, 1e-12)
    vphi = (x * vy - y * vx) / np.maximum(R, 1e-12)

    samples = pd.DataFrame({
        "distance_kpc": dist, "pmra_masyr": pmra, "pmdec_masyr": pmdec, "rv_kms": rv,
        "x_kpc": x, "y_kpc": y, "z_kpc": z, "R_kpc": R, "r3_kpc": r3,
        "vx_kms": vx, "vy_kms": vy, "vz_kms": vz, "vR_kms": vR, "vphi_kms": vphi,
        "vtot_kms": vtot, "Lz_kpc_kms": Lz,
    })
    if cfg.save_mc_samples:
        save_csv(samples, paths["v6_tables"] / "BH140_v6_phase_space_mc_samples.csv")

    def qstats(name: str, arr: np.ndarray) -> Dict[str, float]:
        arr = np.asarray(arr, float)
        return {
            f"{name}_median": float(np.nanmedian(arr)),
            f"{name}_p16": float(np.nanpercentile(arr, 16)),
            f"{name}_p84": float(np.nanpercentile(arr, 84)),
        }

    summary = {
        "mc_iter_valid": int(len(samples)),
        "pmra_used_masyr": float(pmra0),
        "pmdec_used_masyr": float(pmdec0),
        "rv_used_kms": float(rv0),
        "rv_err_used_kms": float(rv_err),
        "phase_space_gate": "MC_phase_space_computed",
    }
    for name, arr in [("Rgc_kpc", R), ("z_kpc", z), ("vR_kms", vR), ("vphi_kms", vphi), ("vz_kms", vz), ("Lz_kpc_kms", Lz), ("vtot_kms", vtot)]:
        summary.update(qstats(name, arr))
    save_csv(pd.DataFrame([summary]), paths["v6_tables"] / "BH140_v6_phase_space_mc_summary.csv")

    # Optional galpy orbit integration.
    orbit_summary = {"orbit_integration_gate": "not_requested", "orbit_mc_n": 0}
    if cfg.integrate_orbit:
        orbit_summary = run_galpy_orbit_mc(cfg, samples)
    save_csv(pd.DataFrame([orbit_summary]), paths["v6_tables"] / "BH140_v6_orbit_integration_summary.csv")
    return {**summary, **orbit_summary}


def run_galpy_orbit_mc(cfg: Config, samples: pd.DataFrame) -> Dict[str, object]:
    paths = cfg.paths()
    try:
        from galpy.orbit import Orbit
        from galpy.potential import MWPotential2014
        from galpy.util import conversion
    except Exception as e:
        return {"orbit_integration_gate": "blocked_galpy_not_installed", "orbit_error": str(e), "orbit_mc_n": 0}

    rng = np.random.default_rng(cfg.random_seed)
    n = min(cfg.orbit_mc_max, len(samples))
    if n < 5:
        return {"orbit_integration_gate": "blocked_too_few_mc_samples", "orbit_mc_n": n}
    idx = rng.choice(len(samples), size=n, replace=False)
    times = np.linspace(-cfg.orbit_tmax_gyr, cfg.orbit_tmax_gyr, cfg.orbit_nsteps) * u.Gyr
    rows = []
    for j in idx:
        s = samples.iloc[j]
        try:
            o = Orbit(
                vxvv=[
                    cfg.ra_deg * u.deg,
                    cfg.dec_deg * u.deg,
                    float(s["distance_kpc"]) * u.kpc,
                    float(s["pmra_masyr"]) * u.mas / u.yr,
                    float(s["pmdec_masyr"]) * u.mas / u.yr,
                    float(s["rv_kms"]) * u.km / u.s,
                ],
                radec=True,
                ro=cfg.solar_ro_kpc,
                vo=229.0,
                solarmotion="schoenrich",
            )
            o.integrate(times, MWPotential2014)
            rows.append({
                "rperi_kpc": float(o.rperi()),
                "rap_kpc": float(o.rap()),
                "zmax_kpc": float(o.zmax()),
                "ecc": float(o.e()),
            })
        except Exception as e:
            rows.append({"rperi_kpc": np.nan, "rap_kpc": np.nan, "zmax_kpc": np.nan, "ecc": np.nan, "error": str(e)})
    df = pd.DataFrame(rows)
    save_csv(df, paths["v6_tables"] / "BH140_v6_galpy_orbit_mc_samples.csv")
    m = df[["rperi_kpc", "rap_kpc", "zmax_kpc", "ecc"]].apply(pd.to_numeric, errors="coerce")
    valid = np.isfinite(m["rperi_kpc"]).sum()
    summary = {"orbit_integration_gate": "galpy_MC_orbit_integrated" if valid >= 5 else "galpy_orbit_failed_most_samples", "orbit_mc_n": int(valid)}
    for col in ["rperi_kpc", "rap_kpc", "zmax_kpc", "ecc"]:
        arr = pd.to_numeric(df[col], errors="coerce").to_numpy(float)
        summary[f"{col}_median"] = float(np.nanmedian(arr)) if np.isfinite(arr).any() else np.nan
        summary[f"{col}_p16"] = float(np.nanpercentile(arr, 16)) if np.isfinite(arr).any() else np.nan
        summary[f"{col}_p84"] = float(np.nanpercentile(arr, 84)) if np.isfinite(arr).any() else np.nan
    return summary


# ----------------------------
# Final compact claim table
# ----------------------------

def build_compact_claim(hst: Dict[str, object], win: Dict[str, object], phase: Dict[str, object], cfg: Config) -> Dict[str, object]:
    # Keep outer claim from v5 report if available.
    outer_claim = "not_evaluated"
    v5_report = cfg.paths()["base"] / "outer_structure_validation" / "BH140_outer_structure_validation_report.json"
    if v5_report.exists():
        try:
            obj = json.loads(v5_report.read_text(encoding="utf-8"))
            outer_claim = obj.get("recommended_outer_claim", obj.get("improved_bootstrap_controls", {}).get("claim_gate_outer_v5", "not_evaluated"))
        except Exception:
            pass
    mf_claim = hst.get("physical_mf_gate", "not_evaluated")
    win_gate = win.get("winered_gate", "not_evaluated")
    orbit_gate = phase.get("orbit_integration_gate", phase.get("phase_space_gate", "not_evaluated"))

    score = 0
    if "strong" in str(outer_claim).lower():
        score += 1
    if str(mf_claim).startswith("physical_MF_computed"):
        score += 1
    if win_gate == "source_level_crossmatch_verified":
        score += 1
    if orbit_gate in ["galpy_MC_orbit_integrated"]:
        score += 1
    elif phase.get("phase_space_gate") == "MC_phase_space_computed":
        score += 0.5

    if score >= 3.5:
        readiness = "validation_ready_physical_validation"
    elif score >= 2.5:
        readiness = "validated_with_minor_physical_followup"
    elif score >= 1.5:
        readiness = "intermediate_candidate"
    else:
        readiness = "diagnostic_only"

    return {
        "outer_structure_claim": outer_claim,
        "hst_mass_function_claim": mf_claim,
        "winered_crossmatch_claim": win_gate,
        "orbit_claim": orbit_gate,
        "validation_score_0_4": score,
        "validation_readiness_gate_v6": readiness,
        "recommended_safe_title": "A Multi-Survey Validation of BH 140: Gaia DR3 Membership, HST/MGCS Photometry, WINERED Spectroscopy, and a Control-Supported Candidate Tidal Structure",
    }


# ----------------------------
# CLI
# ----------------------------

def parse_args() -> Config:
    p = argparse.ArgumentParser(description="BH 140 publication-scale physical modules v6")
    p.add_argument("--outdir", default=Config.outdir)
    p.add_argument("--ra-deg", type=float, default=Config.ra_deg)
    p.add_argument("--dec-deg", type=float, default=Config.dec_deg)
    p.add_argument("--distance-kpc", type=float, default=Config.distance_kpc)
    p.add_argument("--distance-err-kpc", type=float, default=Config.distance_err_kpc)
    p.add_argument("--pmra-masyr", type=float, default=Config.pmra_masyr)
    p.add_argument("--pmdec-masyr", type=float, default=Config.pmdec_masyr)
    p.add_argument("--pm-err-masyr", type=float, default=Config.pm_err_masyr)
    p.add_argument("--rv-los-kms", type=float, default=Config.rv_los_kms)
    p.add_argument("--rv-err-kms", type=float, default=Config.rv_err_kms)
    p.add_argument("--isochrone-csv", default="")
    p.add_argument("--completeness-csv", default="")
    p.add_argument("--winered-csv", default="")
    p.add_argument("--mass-min", type=float, default=Config.mass_min)
    p.add_argument("--mass-max", type=float, default=Config.mass_max)
    p.add_argument("--mass-bins", type=int, default=Config.mass_bins)
    p.add_argument("--mf-bootstrap", type=int, default=Config.mf_bootstrap)
    p.add_argument("--mc-iter", type=int, default=Config.mc_iter)
    p.add_argument("--save-mc-samples", action="store_true")
    p.add_argument("--integrate-orbit", action="store_true")
    p.add_argument("--orbit-tmax-gyr", type=float, default=Config.orbit_tmax_gyr)
    p.add_argument("--orbit-nsteps", type=int, default=Config.orbit_nsteps)
    p.add_argument("--orbit-mc-max", type=int, default=Config.orbit_mc_max)
    p.add_argument("--analyze", action="store_true")
    args = p.parse_args()
    return Config(**vars(args))


def main() -> None:
    setup_logging()
    cfg = parse_args()
    setup_dirs(cfg)
    if not cfg.analyze:
        LOGGER.info("Nothing to do; pass --analyze")
        return
    gaia = load_gaia_members(cfg)
    LOGGER.info("Loaded Gaia member table: %d rows", len(gaia))

    hst_summary = run_hst_mass_function(cfg)
    LOGGER.info("HST/MGCS MF gate: %s", hst_summary.get("physical_mf_gate"))

    win_summary = run_winered_crossmatch_orbit(cfg, gaia)
    LOGGER.info("WINERED gate: %s, crossmatch_n=%s", win_summary.get("winered_gate"), win_summary.get("winered_crossmatch_n"))

    phase_summary = run_phase_space_mc(cfg, win_summary)
    LOGGER.info("Orbit/phase-space gate: %s", phase_summary.get("orbit_integration_gate", phase_summary.get("phase_space_gate")))

    compact = build_compact_claim(hst_summary, win_summary, phase_summary, cfg)
    save_csv(pd.DataFrame([compact]), cfg.paths()["v6_tables"] / "BH140_physical_validation_compact_claim_table.csv")
    report = {
        "config": asdict(cfg),
        "hst_mass_function": hst_summary,
        "winered_crossmatch": win_summary,
        "phase_space_orbit": phase_summary,
        "compact_claim": compact,
    }
    save_json(report, cfg.paths()["v6"] / "BH140_physical_validation_report.json")
    LOGGER.info("V6 complete. Gate: %s", compact["validation_readiness_gate_v6"])


if __name__ == "__main__":
    main()
