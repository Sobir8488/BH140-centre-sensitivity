#!/usr/bin/env python3
"""
03_bootstrap_control_validation.py

publication-scale upgrade module for the BH 140 multi-survey validation project.
Run this AFTER 01_build_membership_catalog.py and bh140_outer_validation_v4.py.

Main goals
----------
1) Improved bootstrap matched-control test for the outer anisotropy.
   Unlike the v4 gate, this does NOT apply the target spatial membership prior
   to control fields.  It uses Gaia-quality + PM/parallax + optional CMD filters,
   constructs outer-annulus pools in each control field, and bootstraps the same
   number of outer-like sources as in the BH 140 target sample.

2) HST/MGCS mass-function readiness and optional completeness-corrected MF.
   If an isochrone CSV and an artificial-star/completeness CSV are supplied, it
   computes a first completeness-corrected inner/outer mass-function comparison.
   If not supplied, it outputs a strict readiness audit rather than making a
   physical mass-function claim.

3) WINERED verification/cross-match and phase-space/orbit-readiness audit.
   If WINERED rows contain coordinates and radial velocities, it cross-matches
   them to Gaia and derives RV/metallicity summary quantities.  It also computes
   a basic Astropy Galactocentric phase-space sanity table using the adopted RV.

Example Spyder/IPython commands
-------------------------------
%run "C:/Users/USER/Desktop/BH_140/03_bootstrap_control_validation.py" --outdir "C:/Users/USER/Desktop/BH_140/results_BH140_multisurvey_validation_v3" --download-controls --analyze

With optional HST mass-function inputs:
%run "C:/Users/USER/Desktop/BH_140/03_bootstrap_control_validation.py" --outdir "C:/Users/USER/Desktop/BH_140/results_BH140_multisurvey_validation_v3" --analyze --isochrone-csv "C:/path/isochrone.csv" --completeness-csv "C:/path/completeness.csv"

Dependencies
------------
numpy, pandas, scipy, matplotlib, astropy, astroquery
Optional: scikit-learn is not required here.
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import re
import sys
import site
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

_USER_SITE = site.getusersitepackages()
if _USER_SITE and _USER_SITE not in sys.path:
    sys.path.insert(0, _USER_SITE)

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.optimize import curve_fit
from astropy import units as u
from astropy.coordinates import SkyCoord, Galactocentric
import matplotlib.pyplot as plt

try:
    from astroquery.gaia import Gaia
except Exception:  # pragma: no cover
    Gaia = None

LOGGER = logging.getLogger("BH140-VALIDATION-V5")


@dataclass
class Config:
    # Target and adopted external parameters.
    ra_deg: float = 193.25125
    dec_deg: float = -67.174444
    radius_deg: float = 0.50
    outdir: str = "results_BH140_multisurvey_validation_v3"
    distance_kpc: float = 4.81
    pmra_lit: float = -14.8685
    pmdec_lit: float = 1.2164
    parallax_exp_mas: float = 1.0 / 4.81
    rv_los_kms: float = 91.72

    # Quality and target selection.
    p_mem_target: float = 0.90
    q_flag_min: int = 2
    outer_quantile: float = 0.90
    ruwe_max: float = 1.4
    vis_periods_min: int = 8

    # Control-field configuration.
    control_sep_deg: float = 1.75
    n_controls: int = 12
    control_radius_deg: float = 0.50
    control_pm_window_masyr: float = 2.50
    control_parallax_halfwidth_mas: float = 0.55
    control_g_min: float = 12.0
    control_g_max: float = 21.0
    control_max_rows: int = 250000
    bootstrap_iter: int = 5000
    bootstrap_min_pool_factor: float = 1.25
    stratified_mag_bins: int = 5
    random_seed: int = 42

    # Optional files.
    isochrone_csv: str = ""
    completeness_csv: str = ""

    # HST/MGCS options.
    hst_inner_outer_split: float = 0.50  # split at median target projected radius in matched sample
    mass_min: float = 0.45
    mass_max: float = 0.90
    mass_bins: int = 6

    def paths(self) -> Dict[str, Path]:
        base = Path(self.outdir)
        return {
            "base": base,
            "raw": base / "data" / "raw",
            "processed": base / "data" / "processed",
            "control_raw": base / "data" / "raw" / "gaia_control_fields_v5",
            "tables": base / "tables",
            "figures": base / "figures",
            "v5": base / "outer_structure_validation",
            "v5_tables": base / "outer_structure_validation" / "tables",
            "v5_figures": base / "outer_structure_validation" / "figures",
        }


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def setup_dirs(cfg: Config) -> None:
    for p in cfg.paths().values():
        p.mkdir(parents=True, exist_ok=True)


def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    LOGGER.info("Saved %d rows to %s", len(df), path)


def save_json(obj: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")
    LOGGER.info("Saved JSON to %s", path)


def finite_numeric(s: pd.Series) -> np.ndarray:
    return np.isfinite(pd.to_numeric(s, errors="coerce").to_numpy(float))


def num(df: pd.DataFrame, col: str) -> np.ndarray:
    return pd.to_numeric(df[col], errors="coerce").to_numpy(float)


def find_col(columns: Iterable[str], patterns: List[str]) -> Optional[str]:
    cols = list(columns)
    lower = {c.lower(): c for c in cols}
    for pat in patterns:
        p = pat.lower()
        if p in lower:
            return lower[p]
    for c in cols:
        cl = c.lower()
        for pat in patterns:
            if re.search(pat.lower(), cl):
                return c
    return None


def tangent_offsets(df: pd.DataFrame, ra0: float, dec0: float,
                    ra_col: str = "ra", dec_col: str = "dec") -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    ra = num(df, ra_col)
    dec = num(df, dec_col)
    cosd = math.cos(math.radians(dec0))
    x = (ra - ra0) * cosd
    y = dec - dec0
    r = np.sqrt(x * x + y * y)
    return x, y, r


def theta_from_xy(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    return np.mod(np.arctan2(y, x), 2.0 * np.pi)


def rayleigh(theta: np.ndarray, m: int = 1) -> Tuple[float, float, float]:
    theta = np.asarray(theta, float)
    theta = theta[np.isfinite(theta)]
    n = theta.size
    if n < 3:
        return np.nan, np.nan, np.nan
    c = np.sum(np.cos(m * theta))
    s = np.sum(np.sin(m * theta))
    R = np.sqrt(c * c + s * s) / n
    p = float(np.exp(-n * R * R))
    pa = np.degrees(np.arctan2(s, c) / m) % (180.0 if m == 2 else 360.0)
    return float(R), p, float(pa)


def angular_distance_deg(a: np.ndarray, b: float, period: float = 360.0) -> np.ndarray:
    return np.abs(((a - b + period / 2.0) % period) - period / 2.0)


def gaia_quality(df: pd.DataFrame, cfg: Config, strict: bool = False) -> np.ndarray:
    mask = np.ones(len(df), dtype=bool)
    for col in ["ra", "dec", "pmra", "pmdec", "parallax"]:
        if col in df:
            mask &= finite_numeric(df[col])
    if "ruwe" in df:
        lim = 1.2 if strict else cfg.ruwe_max
        mask &= finite_numeric(df["ruwe"]) & (num(df, "ruwe") <= lim)
    if "visibility_periods_used" in df:
        lim = max(10, cfg.vis_periods_min) if strict else cfg.vis_periods_min
        mask &= finite_numeric(df["visibility_periods_used"]) & (num(df, "visibility_periods_used") >= lim)
    if "duplicated_source" in df:
        dup = df["duplicated_source"]
        if dup.dtype == bool:
            mask &= ~dup.to_numpy(bool)
        else:
            mask &= ~dup.astype(str).str.lower().isin(["true", "1", "t", "yes"]).to_numpy()
    return mask


def load_gaia_target(cfg: Config) -> pd.DataFrame:
    p = cfg.paths()["processed"] / "gaia_dr3_with_membership.csv"
    if not p.exists():
        raise FileNotFoundError(f"Missing {p}. Run v3 first.")
    df = pd.read_csv(p)
    # Normalize columns if needed.
    for old, new in [("ra_deg", "ra"), ("dec_deg", "dec")]:
        if old in df.columns and new not in df.columns:
            df[new] = df[old]
    return df


def target_selection(df: pd.DataFrame, cfg: Config, strict_quality: bool = False) -> pd.DataFrame:
    mask = gaia_quality(df, cfg, strict=strict_quality)
    if "p_mem" in df:
        mask &= finite_numeric(df["p_mem"]) & (num(df, "p_mem") >= cfg.p_mem_target)
    if "q_flag" in df:
        mask &= pd.to_numeric(df["q_flag"], errors="coerce").fillna(-99).to_numpy(float) >= cfg.q_flag_min
    sel = df.loc[mask].copy()
    x, y, r = tangent_offsets(sel, cfg.ra_deg, cfg.dec_deg)
    sel["x_deg_v5"] = x
    sel["y_deg_v5"] = y
    sel["r_deg_v5"] = r
    sel["theta_rad_v5"] = theta_from_xy(x, y)
    return sel


def target_outer_sample(sel: pd.DataFrame, cfg: Config) -> Tuple[pd.DataFrame, float]:
    if len(sel) < 20:
        raise RuntimeError("Too few target members for outer-anisotropy validation.")
    rcut = float(np.nanquantile(sel["r_deg_v5"], cfg.outer_quantile))
    outer = sel[sel["r_deg_v5"] >= rcut].copy()
    return outer, rcut


def generate_control_centres(cfg: Config) -> pd.DataFrame:
    # Place controls on a ring in Galactic coordinates.  This matches latitude/crowding better than RA rings.
    c0 = SkyCoord(ra=cfg.ra_deg * u.deg, dec=cfg.dec_deg * u.deg, frame="icrs")
    l0 = c0.galactic.l.deg
    b0 = c0.galactic.b.deg
    rows = []
    for i in range(cfg.n_controls):
        phi = 2.0 * math.pi * i / cfg.n_controls
        # Small-angle offsets in Galactic lon/lat.
        dl = cfg.control_sep_deg * math.cos(phi) / max(math.cos(math.radians(b0)), 0.2)
        db = cfg.control_sep_deg * math.sin(phi)
        cc = SkyCoord(l=(l0 + dl) * u.deg, b=(b0 + db) * u.deg, frame="galactic").icrs
        rows.append({
            "field_id": f"CTRL_{i+1:02d}",
            "ra_deg": cc.ra.deg,
            "dec_deg": cc.dec.deg,
            "l_deg": l0 + dl,
            "b_deg": b0 + db,
            "separation_design_deg": cfg.control_sep_deg,
        })
    return pd.DataFrame(rows)


def download_gaia_control_field(row: pd.Series, cfg: Config) -> Optional[Path]:
    if Gaia is None:
        LOGGER.warning("astroquery.gaia unavailable; cannot download control fields.")
        return None
    out = cfg.paths()["control_raw"] / f"{row['field_id']}_gaia.csv"
    if out.exists():
        LOGGER.info("Control field cache exists: %s", out)
        return out
    ra0 = float(row["ra_deg"])
    dec0 = float(row["dec_deg"])
    r = cfg.control_radius_deg
    # Rectangular prefilter; use CONTAINS/CIRCLE can be slower at this density.
    dra = r / max(math.cos(math.radians(dec0)), 0.05)
    pmra0 = cfg.pmra_lit
    pmde0 = cfg.pmdec_lit
    par0 = cfg.parallax_exp_mas
    q = f"""
    SELECT TOP {int(cfg.control_max_rows)}
        source_id, ra, dec, pmra, pmdec, parallax,
        phot_g_mean_mag, bp_rp, ruwe, visibility_periods_used, duplicated_source
    FROM gaiadr3.gaia_source
    WHERE ra BETWEEN {ra0 - dra} AND {ra0 + dra}
      AND dec BETWEEN {dec0 - r} AND {dec0 + r}
      AND pmra BETWEEN {pmra0 - cfg.control_pm_window_masyr} AND {pmra0 + cfg.control_pm_window_masyr}
      AND pmdec BETWEEN {pmde0 - cfg.control_pm_window_masyr} AND {pmde0 + cfg.control_pm_window_masyr}
      AND parallax BETWEEN {par0 - cfg.control_parallax_halfwidth_mas} AND {par0 + cfg.control_parallax_halfwidth_mas}
      AND phot_g_mean_mag BETWEEN {cfg.control_g_min} AND {cfg.control_g_max}
    """
    LOGGER.info("Submitting Gaia control query for %s", row["field_id"])
    job = Gaia.launch_job_async(q, dump_to_file=False)
    tab = job.get_results()
    df = tab.to_pandas()
    save_csv(df, out)
    return out


def ensure_control_files(cfg: Config, download: bool) -> pd.DataFrame:
    centres_path = cfg.paths()["tables"] / "BH140_control_field_centres_v5.csv"
    if centres_path.exists():
        centres = pd.read_csv(centres_path)
    else:
        # Reuse v4 centres if present, but v5 default can be 12.  If v4 has fewer, generate v5 fresh.
        old = cfg.paths()["tables"] / "BH140_control_field_centres.csv"
        if old.exists():
            centres_old = pd.read_csv(old)
            if len(centres_old) >= cfg.n_controls:
                centres = centres_old.head(cfg.n_controls).copy()
            else:
                centres = generate_control_centres(cfg)
        else:
            centres = generate_control_centres(cfg)
        save_csv(centres, centres_path)
    if download:
        for _, row in centres.iterrows():
            try:
                download_gaia_control_field(row, cfg)
            except Exception as exc:
                LOGGER.warning("Control-field download failed for %s: %s", row.get("field_id"), exc)
    return centres


def control_candidate_pool(df: pd.DataFrame, row: pd.Series, target_sel: pd.DataFrame,
                           r_outer_threshold: float, cfg: Config) -> pd.DataFrame:
    df = df.copy()
    # Normalize columns.
    if "dec" not in df.columns and "de" in df.columns:
        df["dec"] = df["de"]
    mask = gaia_quality(df, cfg, strict=False)
    if "phot_g_mean_mag" in df.columns:
        g = num(df, "phot_g_mean_mag")
        tg = num(target_sel, "phot_g_mean_mag") if "phot_g_mean_mag" in target_sel.columns else None
        if tg is not None and np.isfinite(tg).sum() > 20:
            lo, hi = np.nanpercentile(tg, [1, 99])
            mask &= np.isfinite(g) & (g >= lo) & (g <= hi)
    if "bp_rp" in df.columns and "bp_rp" in target_sel.columns:
        c = num(df, "bp_rp")
        tc = num(target_sel, "bp_rp")
        if np.isfinite(tc).sum() > 20:
            lo, hi = np.nanpercentile(tc, [1, 99])
            mask &= np.isfinite(c) & (c >= lo - 0.15) & (c <= hi + 0.15)
    pmra = num(df, "pmra")
    pmde = num(df, "pmdec")
    plx = num(df, "parallax")
    dpm = np.sqrt((pmra - cfg.pmra_lit) ** 2 + (pmde - cfg.pmdec_lit) ** 2)
    mask &= dpm <= cfg.control_pm_window_masyr
    mask &= np.abs(plx - cfg.parallax_exp_mas) <= cfg.control_parallax_halfwidth_mas
    sub = df.loc[mask].copy()
    if len(sub) == 0:
        return sub
    x, y, r = tangent_offsets(sub, float(row["ra_deg"]), float(row["dec_deg"]))
    sub["x_deg_v5"] = x
    sub["y_deg_v5"] = y
    sub["r_deg_v5"] = r
    sub["theta_rad_v5"] = theta_from_xy(x, y)
    # Use same geometric annulus as target outer region, not a membership prior.
    sub = sub[(sub["r_deg_v5"] >= r_outer_threshold) & (sub["r_deg_v5"] <= cfg.control_radius_deg)].copy()
    return sub


def stratified_bootstrap_indices(pool: pd.DataFrame, target_outer: pd.DataFrame,
                                 n: int, rng: np.random.Generator, cfg: Config) -> np.ndarray:
    # Match target magnitude distribution if G exists.  Falls back to simple bootstrap.
    if "phot_g_mean_mag" not in pool.columns or "phot_g_mean_mag" not in target_outer.columns:
        return rng.choice(pool.index.to_numpy(), size=n, replace=len(pool) < n)
    pg = pd.to_numeric(pool["phot_g_mean_mag"], errors="coerce")
    tg = pd.to_numeric(target_outer["phot_g_mean_mag"], errors="coerce")
    if pg.notna().sum() < max(10, n // 2) or tg.notna().sum() < 10:
        return rng.choice(pool.index.to_numpy(), size=n, replace=len(pool) < n)
    edges = np.nanquantile(tg.to_numpy(float), np.linspace(0, 1, cfg.stratified_mag_bins + 1))
    edges = np.unique(edges)
    if len(edges) < 3:
        return rng.choice(pool.index.to_numpy(), size=n, replace=len(pool) < n)
    chosen = []
    remaining = n
    for lo, hi in zip(edges[:-1], edges[1:]):
        tcount = int(((tg >= lo) & (tg <= hi)).sum())
        if tcount <= 0:
            continue
        pidx = pool.index[(pg >= lo) & (pg <= hi)].to_numpy()
        if len(pidx) == 0:
            continue
        take = min(tcount, remaining)
        chosen.extend(rng.choice(pidx, size=take, replace=len(pidx) < take).tolist())
        remaining -= take
    if remaining > 0:
        allidx = pool.index.to_numpy()
        chosen.extend(rng.choice(allidx, size=remaining, replace=len(allidx) < remaining).tolist())
    return np.array(chosen[:n])


def improved_bootstrap_controls(cfg: Config, download_controls: bool) -> Dict[str, object]:
    paths = cfg.paths()
    gaia = load_gaia_target(cfg)
    target_sel = target_selection(gaia, cfg, strict_quality=False)
    target_outer, rcut = target_outer_sample(target_sel, cfg)
    theta_t = target_outer["theta_rad_v5"].to_numpy(float)
    R1, p1, pa1 = rayleigh(theta_t, m=1)
    R2, p2, pa2 = rayleigh(theta_t, m=2)
    target_n = len(target_outer)
    LOGGER.info("Target outer sample: N=%d R1=%.4f p1=%.3g R2=%.4f p2=%.3g", target_n, R1, p1, R2, p2)

    centres = ensure_control_files(cfg, download=download_controls)
    rng = np.random.default_rng(cfg.random_seed)
    field_rows = []
    boot_rows = []

    for _, crow in centres.iterrows():
        fid = str(crow["field_id"])
        fpath = paths["control_raw"] / f"{fid}_gaia.csv"
        # Fallback to v4 control cache if v5 file not present.
        if not fpath.exists():
            old1 = paths["base"] / "data" / "raw" / "gaia_control_fields" / f"{fid}_gaia.csv"
            old2 = paths["base"] / "data" / "raw" / "gaia_control_fields" / f"{fid}.csv"
            if old1.exists():
                fpath = old1
            elif old2.exists():
                fpath = old2
        if not fpath.exists():
            LOGGER.warning("Missing control field CSV for %s", fid)
            field_rows.append({"field_id": fid, "status": "missing", "pool_n": 0})
            continue
        dfc = pd.read_csv(fpath)
        pool = control_candidate_pool(dfc, crow, target_sel, rcut, cfg)
        pool_n = len(pool)
        comparable = pool_n >= max(10, int(cfg.bootstrap_min_pool_factor * target_n))
        field_rows.append({
            "field_id": fid,
            "status": "ok" if pool_n > 0 else "empty_after_filter",
            "pool_n": pool_n,
            "target_outer_n": target_n,
            "comparable_pool": bool(comparable),
            "ra_deg": float(crow["ra_deg"]),
            "dec_deg": float(crow["dec_deg"]),
            "r_outer_threshold_deg": rcut,
        })
        if pool_n < 3:
            continue
        # Even if not comparable, produce a flagged bootstrap with replacement for diagnostics.
        for b in range(cfg.bootstrap_iter):
            idx = stratified_bootstrap_indices(pool, target_outer, target_n, rng, cfg)
            th = pool.loc[idx, "theta_rad_v5"].to_numpy(float)
            bR1, bp1, bpa1 = rayleigh(th, m=1)
            bR2, bp2, bpa2 = rayleigh(th, m=2)
            boot_rows.append({
                "field_id": fid,
                "bootstrap_id": b,
                "pool_n": pool_n,
                "comparable_pool": bool(comparable),
                "R1": bR1,
                "p1": bp1,
                "PA1_deg": bpa1,
                "R2": bR2,
                "p2": bp2,
                "PA2_deg": bpa2,
            })

    field_df = pd.DataFrame(field_rows)
    boot_df = pd.DataFrame(boot_rows)
    save_csv(field_df, paths["v5_tables"] / "BH140_v5_control_pool_audit.csv")
    save_csv(boot_df, paths["v5_tables"] / "BH140_v5_bootstrap_control_distribution.csv")

    if len(boot_df) > 0:
        valid = boot_df[np.isfinite(boot_df["R1"]) & np.isfinite(boot_df["R2"])]
        valid_comp = valid[valid["comparable_pool"] == True]
        comp_used = len(valid_comp) > 0
        eval_df = valid_comp if comp_used else valid
        fp_R1 = (1 + int((eval_df["R1"] >= R1).sum())) / (1 + len(eval_df)) if len(eval_df) else np.nan
        fp_R2 = (1 + int((eval_df["R2"] >= R2).sum())) / (1 + len(eval_df)) if len(eval_df) else np.nan
        perc_R1 = 100.0 * float((eval_df["R1"] <= R1).mean()) if len(eval_df) else np.nan
        perc_R2 = 100.0 * float((eval_df["R2"] <= R2).mean()) if len(eval_df) else np.nan
    else:
        fp_R1 = fp_R2 = perc_R1 = perc_R2 = np.nan
        comp_used = False
        eval_df = pd.DataFrame()

    if np.isfinite(fp_R1) and np.isfinite(fp_R2):
        if fp_R1 <= 0.01 and fp_R2 <= 0.01 and comp_used:
            gate = "strong_control_supported_tidal_structure_candidate"
        elif fp_R1 <= 0.05 and comp_used:
            gate = "control_supported_lopsided_outer_anisotropy"
        elif not comp_used:
            gate = "candidate_controls_not_comparable"
        else:
            gate = "candidate_control_sensitive"
    else:
        gate = "candidate_control_validation_failed"

    summary = {
        "target_outer_n": int(target_n),
        "target_r_outer_threshold_deg": float(rcut),
        "target_R1": float(R1),
        "target_p1": float(p1),
        "target_PA1_deg": float(pa1),
        "target_R2": float(R2),
        "target_p2": float(p2),
        "target_PA2_deg": float(pa2),
        "n_control_fields": int(len(centres)),
        "n_control_fields_with_pool": int((field_df.get("pool_n", pd.Series(dtype=int)) > 0).sum()) if len(field_df) else 0,
        "n_comparable_control_fields": int((field_df.get("comparable_pool", pd.Series(dtype=bool)) == True).sum()) if len(field_df) else 0,
        "n_bootstrap_total": int(len(boot_df)),
        "used_comparable_only": bool(comp_used),
        "bootstrap_fp_R1": float(fp_R1) if np.isfinite(fp_R1) else np.nan,
        "bootstrap_fp_R2": float(fp_R2) if np.isfinite(fp_R2) else np.nan,
        "target_R1_percentile": float(perc_R1) if np.isfinite(perc_R1) else np.nan,
        "target_R2_percentile": float(perc_R2) if np.isfinite(perc_R2) else np.nan,
        "claim_gate_outer_v5": gate,
    }
    save_csv(pd.DataFrame([summary]), paths["v5_tables"] / "BH140_v5_bootstrap_control_summary.csv")

    # Plots.
    if len(boot_df) > 0:
        for col, target_val, label in [("R1", R1, "Rayleigh R1"), ("R2", R2, "Axial R2")]:
            plt.figure(figsize=(7.5, 5))
            x = pd.to_numeric(boot_df[col], errors="coerce").to_numpy(float)
            x = x[np.isfinite(x)]
            plt.hist(x, bins=40, alpha=0.8)
            plt.axvline(target_val, linestyle="--", linewidth=2)
            plt.xlabel(label)
            plt.ylabel("bootstrap count")
            plt.title(f"BH 140 target vs matched-control bootstrap: {label}")
            plt.tight_layout()
            pfig = paths["v5_figures"] / f"BH140_v5_bootstrap_control_{col}.png"
            plt.savefig(pfig, dpi=180)
            plt.close()
            LOGGER.info("Saved figure %s", pfig)

    return summary


# -------------------------------------------------------------------------
# HST/MGCS mass-function readiness and optional MF module
# -------------------------------------------------------------------------

def find_hst_crossmatch(paths: Dict[str, Path]) -> Optional[Path]:
    candidates = list((paths["processed"]).glob("crossmatch_gaia_mgcs_*astro*.csv"))
    candidates = [p for p in candidates if "astroinf" not in p.name.lower() and "list" not in p.name.lower()]
    if not candidates:
        candidates = list((paths["processed"]).glob("crossmatch_gaia_mgcs_*.csv"))
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_size, reverse=True)
    return candidates[0]


def infer_hst_cmd_columns(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    # Returns mag1, mag2, color, radius column if available.
    cols = list(df.columns)
    f606 = find_col(cols, [r"f606w", r"606"])
    f814 = find_col([c for c in cols if c != f606], [r"f814w", r"814"])
    # Alternative MGCS filters can be present.
    if f606 is None:
        f606 = find_col(cols, [r"f555w", r"f475w", r"mag1", r"m1"])
    if f814 is None:
        f814 = find_col([c for c in cols if c != f606], [r"f814w", r"f775w", r"mag2", r"m2"])
    color = find_col(cols, [r"color", r"f606.*f814", r"606.*814", r"bp_rp"])
    radius = find_col(cols, [r"r_deg_v5", r"r_deg", r"radius", r"r_pc"])
    return f606, f814, color, radius


def nearest_isochrone_mass(stars: pd.DataFrame, iso: pd.DataFrame,
                           star_mag: str, star_color: Optional[str],
                           iso_mag: str, iso_color: str, iso_mass: str) -> np.ndarray:
    smag = pd.to_numeric(stars[star_mag], errors="coerce").to_numpy(float)
    if star_color is not None:
        scol = pd.to_numeric(stars[star_color], errors="coerce").to_numpy(float)
    else:
        return np.full(len(stars), np.nan)
    imag = pd.to_numeric(iso[iso_mag], errors="coerce").to_numpy(float)
    icol = pd.to_numeric(iso[iso_color], errors="coerce").to_numpy(float)
    imass = pd.to_numeric(iso[iso_mass], errors="coerce").to_numpy(float)
    ok_iso = np.isfinite(imag) & np.isfinite(icol) & np.isfinite(imass)
    imag, icol, imass = imag[ok_iso], icol[ok_iso], imass[ok_iso]
    if len(imass) < 5:
        return np.full(len(stars), np.nan)
    # Scale dimensions by robust ranges to avoid one axis dominating.
    s1 = np.nanstd(imag) or 1.0
    s2 = np.nanstd(icol) or 1.0
    tree = cKDTree(np.column_stack([imag / s1, icol / s2]))
    ok = np.isfinite(smag) & np.isfinite(scol)
    out = np.full(len(stars), np.nan)
    dist, idx = tree.query(np.column_stack([smag[ok] / s1, scol[ok] / s2]), k=1)
    out[ok] = imass[idx]
    return out


def completeness_weights(stars: pd.DataFrame, comp: Optional[pd.DataFrame], mag_col: str,
                         radius_col: Optional[str]) -> np.ndarray:
    if comp is None or len(comp) == 0:
        return np.ones(len(stars), dtype=float)
    cols = comp.columns
    c_mag = find_col(cols, [r"mag", r"f606", r"f814", r"ks", r"g"])
    c_rad = find_col(cols, [r"r", r"radius", r"rad"])
    c_comp = find_col(cols, [r"comp", r"complete", r"C$", r"frac", r"recovery"])
    if c_mag is None or c_comp is None:
        LOGGER.warning("Could not infer completeness columns; using unit weights.")
        return np.ones(len(stars), dtype=float)
    mstar = pd.to_numeric(stars[mag_col], errors="coerce").to_numpy(float)
    cmag = pd.to_numeric(comp[c_mag], errors="coerce").to_numpy(float)
    cval = pd.to_numeric(comp[c_comp], errors="coerce").to_numpy(float)
    if c_rad is not None and radius_col is not None and radius_col in stars.columns:
        rstar = pd.to_numeric(stars[radius_col], errors="coerce").to_numpy(float)
        crad = pd.to_numeric(comp[c_rad], errors="coerce").to_numpy(float)
        okc = np.isfinite(cmag) & np.isfinite(crad) & np.isfinite(cval) & (cval > 0)
        if okc.sum() >= 5:
            sm = np.nanstd(cmag[okc]) or 1.0
            sr = np.nanstd(crad[okc]) or 1.0
            tree = cKDTree(np.column_stack([cmag[okc] / sm, crad[okc] / sr]))
            ok = np.isfinite(mstar) & np.isfinite(rstar)
            w = np.ones(len(stars), dtype=float)
            _, idx = tree.query(np.column_stack([mstar[ok] / sm, rstar[ok] / sr]))
            c = cval[okc][idx]
            w[ok] = 1.0 / np.clip(c, 0.05, 1.0)
            return w
    okc = np.isfinite(cmag) & np.isfinite(cval) & (cval > 0)
    if okc.sum() < 3:
        return np.ones(len(stars), dtype=float)
    order = np.argsort(cmag[okc])
    c_interp = np.interp(mstar, cmag[okc][order], cval[okc][order], left=np.nan, right=np.nan)
    return 1.0 / np.clip(np.where(np.isfinite(c_interp), c_interp, 1.0), 0.05, 1.0)


def fit_mass_function_slope(mass: np.ndarray, weights: np.ndarray, cfg: Config) -> Tuple[float, float, int]:
    ok = np.isfinite(mass) & np.isfinite(weights) & (mass >= cfg.mass_min) & (mass <= cfg.mass_max) & (weights > 0)
    mass = mass[ok]
    weights = weights[ok]
    if len(mass) < 30:
        return np.nan, np.nan, int(len(mass))
    bins = np.linspace(cfg.mass_min, cfg.mass_max, cfg.mass_bins + 1)
    counts, edges = np.histogram(mass, bins=bins, weights=weights)
    widths = np.diff(edges)
    mids = np.sqrt(edges[:-1] * edges[1:])
    y = counts / widths
    okb = (y > 0) & np.isfinite(y) & np.isfinite(mids)
    if okb.sum() < 3:
        return np.nan, np.nan, int(len(mass))
    x = np.log10(mids[okb])
    yy = np.log10(y[okb])
    # dN/dm ∝ m^alpha, so log(dN/dm)=alpha log(m)+const.
    coef, cov = np.polyfit(x, yy, 1, cov=True)
    alpha = float(coef[0])
    err = float(np.sqrt(cov[0, 0])) if cov.shape == (2, 2) and np.isfinite(cov[0, 0]) else np.nan
    return alpha, err, int(len(mass))


def hst_mass_function_module(cfg: Config) -> Dict[str, object]:
    paths = cfg.paths()
    xmatch_path = find_hst_crossmatch(paths)
    status_rows = []
    mf_summary = {}
    if xmatch_path is None:
        status = {"layer": "HST/MGCS", "status": "missing_crossmatch", "n": 0, "claim": "no_physical_mass_function"}
        save_csv(pd.DataFrame([status]), paths["v5_tables"] / "BH140_v5_hst_mass_function_status.csv")
        return status
    hst = pd.read_csv(xmatch_path)
    mag1, mag2, color_col, r_col = infer_hst_cmd_columns(hst)
    if color_col is None and mag1 and mag2:
        hst["hst_color_v5"] = pd.to_numeric(hst[mag1], errors="coerce") - pd.to_numeric(hst[mag2], errors="coerce")
        color_col = "hst_color_v5"
    iso_path = Path(cfg.isochrone_csv) if cfg.isochrone_csv else None
    comp_path = Path(cfg.completeness_csv) if cfg.completeness_csv else None
    iso_available = iso_path is not None and iso_path.exists()
    comp_available = comp_path is not None and comp_path.exists()
    status_rows.append({"item": "hst_crossmatch", "status": "available", "n": len(hst), "path": str(xmatch_path)})
    status_rows.append({"item": "hst_mag_column_1", "status": mag1 or "not_found", "n": np.nan, "path": ""})
    status_rows.append({"item": "hst_mag_column_2", "status": mag2 or "not_found", "n": np.nan, "path": ""})
    status_rows.append({"item": "hst_color_column", "status": color_col or "not_found", "n": np.nan, "path": ""})
    status_rows.append({"item": "isochrone_csv", "status": "available" if iso_available else "missing", "n": np.nan, "path": str(iso_path or "")})
    status_rows.append({"item": "completeness_csv", "status": "available" if comp_available else "missing", "n": np.nan, "path": str(comp_path or "")})

    if not (mag1 and color_col and iso_available):
        status_rows.append({"item": "physical_mass_function_gate", "status": "blocked_missing_isochrone_or_cmd_columns", "n": len(hst), "path": ""})
        save_csv(pd.DataFrame(status_rows), paths["v5_tables"] / "BH140_v5_hst_mass_function_status.csv")
        return {"hst_n": len(hst), "physical_mf_gate": "blocked_missing_isochrone_or_cmd_columns"}

    iso = pd.read_csv(iso_path)
    iso_mass = find_col(iso.columns, [r"mass", r"mini", r"m_ini", r"M_ini"])
    iso_mag = find_col(iso.columns, [re.escape(mag1), r"f606", r"f814", r"mag", r"Gmag"])
    iso_color = find_col(iso.columns, [r"color", r"f606.*f814", r"bp_rp"])
    if iso_color is None:
        im1 = find_col(iso.columns, [r"f606", r"f555", r"mag1"])
        im2 = find_col(iso.columns, [r"f814", r"f775", r"mag2"])
        if im1 and im2:
            iso["iso_color_v5"] = pd.to_numeric(iso[im1], errors="coerce") - pd.to_numeric(iso[im2], errors="coerce")
            iso_color = "iso_color_v5"
            if iso_mag is None:
                iso_mag = im1
    if iso_mass is None or iso_mag is None or iso_color is None:
        status_rows.append({"item": "physical_mass_function_gate", "status": "blocked_cannot_infer_isochrone_columns", "n": len(hst), "path": ""})
        save_csv(pd.DataFrame(status_rows), paths["v5_tables"] / "BH140_v5_hst_mass_function_status.csv")
        return {"hst_n": len(hst), "physical_mf_gate": "blocked_cannot_infer_isochrone_columns"}

    hst["mass_iso_v5"] = nearest_isochrone_mass(hst, iso, mag1, color_col, iso_mag, iso_color, iso_mass)
    comp = pd.read_csv(comp_path) if comp_available else None
    hst["comp_weight_v5"] = completeness_weights(hst, comp, mag1, r_col)
    if r_col is None:
        # Try to reconstruct radius from RA/Dec columns if present.
        ra_col = find_col(hst.columns, [r"ra", r"_RA", r"RAJ2000"])
        de_col = find_col(hst.columns, [r"dec", r"de", r"_DE", r"DEJ2000"])
        if ra_col and de_col:
            _, _, rr = tangent_offsets(hst.rename(columns={ra_col: "ra", de_col: "dec"}), cfg.ra_deg, cfg.dec_deg)
            hst["r_deg_hst_v5"] = rr
            r_col = "r_deg_hst_v5"
    if r_col is None:
        hst["radial_bin_v5"] = "all"
        splits = {"all": hst}
    else:
        rr = pd.to_numeric(hst[r_col], errors="coerce")
        split = float(np.nanquantile(rr, cfg.hst_inner_outer_split))
        hst["radial_bin_v5"] = np.where(rr <= split, "inner", "outer")
        splits = {"inner": hst[hst["radial_bin_v5"] == "inner"], "outer": hst[hst["radial_bin_v5"] == "outer"], "all": hst}

    rows = []
    for name, sub in splits.items():
        alpha, alpha_err, nfit = fit_mass_function_slope(sub["mass_iso_v5"].to_numpy(float), sub["comp_weight_v5"].to_numpy(float), cfg)
        rows.append({"radial_bin": name, "n_total": len(sub), "n_mass_fit": nfit, "alpha": alpha, "alpha_err": alpha_err})
    mf = pd.DataFrame(rows)
    save_csv(hst, paths["v5_tables"] / "BH140_v5_hst_crossmatch_with_mass.csv")
    save_csv(mf, paths["v5_tables"] / "BH140_v5_hst_mass_function_summary.csv")
    status_rows.append({"item": "physical_mass_function_gate", "status": "computed_diagnostic_mf" if not comp_available else "computed_completeness_corrected_mf", "n": len(hst), "path": "BH140_v5_hst_mass_function_summary.csv"})
    save_csv(pd.DataFrame(status_rows), paths["v5_tables"] / "BH140_v5_hst_mass_function_status.csv")
    mf_summary = {"hst_n": len(hst), "physical_mf_gate": status_rows[-1]["status"]}
    for _, row in mf.iterrows():
        mf_summary[f"alpha_{row['radial_bin']}"] = row["alpha"]
        mf_summary[f"alpha_err_{row['radial_bin']}"] = row["alpha_err"]
        mf_summary[f"n_fit_{row['radial_bin']}"] = row["n_mass_fit"]
    return mf_summary


# -------------------------------------------------------------------------
# WINERED verification and orbit-readiness
# -------------------------------------------------------------------------

def find_winered_file(paths: Dict[str, Path]) -> Optional[Path]:
    candidates = list((paths["raw"]).glob("*winered*.csv")) + list((paths["processed"]).glob("*winered*.csv"))
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_size, reverse=True)
    return candidates[0]


def crossmatch_by_sky(df1: pd.DataFrame, df2: pd.DataFrame, ra1: str, dec1: str, ra2: str, dec2: str,
                      max_sep_arcsec: float = 1.0) -> pd.DataFrame:
    c1 = SkyCoord(ra=pd.to_numeric(df1[ra1], errors="coerce").to_numpy(float) * u.deg,
                  dec=pd.to_numeric(df1[dec1], errors="coerce").to_numpy(float) * u.deg)
    c2 = SkyCoord(ra=pd.to_numeric(df2[ra2], errors="coerce").to_numpy(float) * u.deg,
                  dec=pd.to_numeric(df2[dec2], errors="coerce").to_numpy(float) * u.deg)
    idx, sep2d, _ = c1.match_to_catalog_sky(c2)
    ok = sep2d.arcsec <= max_sep_arcsec
    left = df1.loc[ok].reset_index(drop=True).copy()
    right = df2.iloc[idx[ok]].reset_index(drop=True).add_prefix("gaia_")
    out = pd.concat([left, right], axis=1)
    out["match_sep_arcsec"] = sep2d.arcsec[ok]
    return out


def winered_orbit_module(cfg: Config) -> Dict[str, object]:
    paths = cfg.paths()
    out = {}
    wpath = find_winered_file(paths)
    if wpath is None:
        status = {"winered_status": "missing_file", "winered_crossmatch_n": 0}
    else:
        wr = pd.read_csv(wpath)
        status = {"winered_status": "available", "winered_rows": len(wr), "winered_file": str(wpath)}
        ra_col = find_col(wr.columns, [r"ra", r"RAJ2000", r"_RA"])
        dec_col = find_col(wr.columns, [r"dec", r"de", r"DEJ2000", r"_DE"])
        rv_col = find_col(wr.columns, [r"rv", r"vlos", r"vr", r"radial", r"velocity"])
        feh_col = find_col(wr.columns, [r"feh", r"\[fe/h\]", r"metal"])
        status.update({"ra_col": ra_col or "not_found", "dec_col": dec_col or "not_found", "rv_col": rv_col or "not_found", "feh_col": feh_col or "not_found"})
        if ra_col and dec_col:
            gaia_primary_path = paths["processed"] / "gaia_primary_members.csv"
            if gaia_primary_path.exists():
                gp = pd.read_csv(gaia_primary_path)
            else:
                gp = target_selection(load_gaia_target(cfg), cfg)
            try:
                cm = crossmatch_by_sky(wr, gp, ra_col, dec_col, "ra", "dec", max_sep_arcsec=1.0)
                save_csv(cm, paths["v5_tables"] / "BH140_v5_winered_gaia_crossmatch.csv")
                status["winered_crossmatch_n"] = len(cm)
                if rv_col and rv_col in cm.columns:
                    rv = pd.to_numeric(cm[rv_col], errors="coerce").to_numpy(float)
                    status["rv_median_kms"] = float(np.nanmedian(rv)) if np.isfinite(rv).any() else np.nan
                    status["rv_mad_kms"] = float(1.4826 * np.nanmedian(np.abs(rv - np.nanmedian(rv)))) if np.isfinite(rv).sum() > 2 else np.nan
                if feh_col and feh_col in cm.columns:
                    feh = pd.to_numeric(cm[feh_col], errors="coerce").to_numpy(float)
                    status["feh_median"] = float(np.nanmedian(feh)) if np.isfinite(feh).any() else np.nan
            except Exception as exc:
                status["winered_crossmatch_error"] = str(exc)
                status["winered_crossmatch_n"] = 0
        else:
            status["winered_crossmatch_n"] = 0
    # Basic phase-space sanity from adopted RV.
    try:
        c = SkyCoord(
            ra=cfg.ra_deg * u.deg,
            dec=cfg.dec_deg * u.deg,
            distance=cfg.distance_kpc * u.kpc,
            pm_ra_cosdec=cfg.pmra_lit * u.mas / u.yr,
            pm_dec=cfg.pmdec_lit * u.mas / u.yr,
            radial_velocity=cfg.rv_los_kms * u.km / u.s,
        )
        gc = c.transform_to(Galactocentric())
        x = gc.x.to_value(u.kpc)
        y = gc.y.to_value(u.kpc)
        z = gc.z.to_value(u.kpc)
        vx = gc.v_x.to_value(u.km / u.s)
        vy = gc.v_y.to_value(u.km / u.s)
        vz = gc.v_z.to_value(u.km / u.s)
        Rgc = float(np.sqrt(x * x + y * y + z * z))
        Lz = float(x * vy - y * vx)
        status.update({
            "adopted_rv_los_kms": cfg.rv_los_kms,
            "galactocentric_x_kpc": float(x),
            "galactocentric_y_kpc": float(y),
            "galactocentric_z_kpc": float(z),
            "galactocentric_R_kpc": Rgc,
            "galactocentric_vx_kms": float(vx),
            "galactocentric_vy_kms": float(vy),
            "galactocentric_vz_kms": float(vz),
            "Lz_kpc_kms": Lz,
            "orbit_gate": "phase_space_sanity_only__full_orbit_requires_MC_potential",
        })
    except Exception as exc:
        status["orbit_gate"] = f"failed_astropy_phase_space: {exc}"
    save_csv(pd.DataFrame([status]), paths["v5_tables"] / "BH140_v5_winered_orbit_status.csv")
    return status


def build_final_report(cfg: Config, control_summary: dict, hst_summary: dict, winered_summary: dict) -> dict:
    # Claim decision for publication-scale readiness.
    outer_gate = control_summary.get("claim_gate_outer_v5", "not_run")
    hst_gate = hst_summary.get("physical_mf_gate", "not_run")
    win_gate = "available" if winered_summary.get("winered_status") == "available" else "missing"
    validation_score = 0
    validation_score += 1 if "control_supported" in outer_gate else 0
    validation_score += 1 if "computed" in str(hst_gate) else 0
    validation_score += 1 if win_gate == "available" else 0
    validation_score += 1 if winered_summary.get("winered_crossmatch_n", 0) and winered_summary.get("winered_crossmatch_n", 0) > 0 else 0
    if validation_score >= 3:
        readiness = "validated_with_cautious_claims"
    elif validation_score == 2:
        readiness = "intermediate_candidate"
    else:
        readiness = "diagnostic_paper_needs_more_validation"
    report = {
        "config": asdict(cfg),
        "improved_bootstrap_controls": control_summary,
        "hst_mass_function": hst_summary,
        "winered_orbit": winered_summary,
        "validation_validation_score_0_4": validation_score,
        "validation_readiness_gate": readiness,
        "recommended_outer_claim": (
            "strong tidal-structure candidate" if "tidal" in outer_gate else
            "control-supported lopsided outer anisotropy" if "control_supported" in outer_gate else
            "candidate control-sensitive outer-member anisotropy"
        ),
        "recommended_mass_function_claim": (
            "completeness-corrected HST mass-function comparison" if "completeness" in str(hst_gate) else
            "diagnostic HST mass-function readiness only" if "blocked" in str(hst_gate) else
            str(hst_gate)
        ),
    }
    save_json(report, cfg.paths()["v5"] / "BH140_outer_structure_validation_report.json")
    save_csv(pd.DataFrame([{
        "validation_validation_score_0_4": validation_score,
        "validation_readiness_gate": readiness,
        "outer_gate": outer_gate,
        "hst_gate": hst_gate,
        "winered_gate": win_gate,
        "winered_crossmatch_n": winered_summary.get("winered_crossmatch_n", 0),
        "recommended_outer_claim": report["recommended_outer_claim"],
        "recommended_mass_function_claim": report["recommended_mass_function_claim"],
    }]), cfg.paths()["v5_tables"] / "BH140_outer_structure_validation_compact_claim_table.csv")
    return report


def run(cfg: Config, download_controls: bool, analyze: bool) -> None:
    setup_dirs(cfg)
    if not analyze:
        ensure_control_files(cfg, download=download_controls)
        LOGGER.info("Download-only step complete.")
        return
    control_summary = improved_bootstrap_controls(cfg, download_controls=download_controls)
    hst_summary = hst_mass_function_module(cfg)
    winered_summary = winered_orbit_module(cfg)
    report = build_final_report(cfg, control_summary, hst_summary, winered_summary)
    LOGGER.info("V5 complete. Compact gate: %s", report.get("validation_readiness_gate"))
    LOGGER.info("Recommended outer claim: %s", report.get("recommended_outer_claim"))
    LOGGER.info("Recommended MF claim: %s", report.get("recommended_mass_function_claim"))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="publication-scale v5 upgrade module for BH 140")
    p.add_argument("--ra-deg", type=float, default=Config.ra_deg)
    p.add_argument("--dec-deg", type=float, default=Config.dec_deg)
    p.add_argument("--radius-deg", type=float, default=Config.radius_deg)
    p.add_argument("--outdir", default=Config.outdir)
    p.add_argument("--distance-kpc", type=float, default=Config.distance_kpc)
    p.add_argument("--pmra-lit", type=float, default=Config.pmra_lit)
    p.add_argument("--pmdec-lit", type=float, default=Config.pmdec_lit)
    p.add_argument("--rv-los-kms", type=float, default=Config.rv_los_kms)
    p.add_argument("--p-mem-target", type=float, default=Config.p_mem_target)
    p.add_argument("--outer-quantile", type=float, default=Config.outer_quantile)
    p.add_argument("--control-sep-deg", type=float, default=Config.control_sep_deg)
    p.add_argument("--n-controls", type=int, default=Config.n_controls)
    p.add_argument("--control-radius-deg", type=float, default=Config.control_radius_deg)
    p.add_argument("--control-pm-window-masyr", type=float, default=Config.control_pm_window_masyr)
    p.add_argument("--control-parallax-halfwidth-mas", type=float, default=Config.control_parallax_halfwidth_mas)
    p.add_argument("--bootstrap-iter", type=int, default=Config.bootstrap_iter)
    p.add_argument("--isochrone-csv", default="")
    p.add_argument("--completeness-csv", default="")
    p.add_argument("--download-controls", action="store_true")
    p.add_argument("--analyze", action="store_true")
    return p


def main(argv: Optional[List[str]] = None) -> None:
    setup_logging()
    args = build_parser().parse_args(argv)
    cfg = Config(
        ra_deg=args.ra_deg,
        dec_deg=args.dec_deg,
        radius_deg=args.radius_deg,
        outdir=args.outdir,
        distance_kpc=args.distance_kpc,
        pmra_lit=args.pmra_lit,
        pmdec_lit=args.pmdec_lit,
        parallax_exp_mas=1.0 / args.distance_kpc,
        rv_los_kms=args.rv_los_kms,
        p_mem_target=args.p_mem_target,
        outer_quantile=args.outer_quantile,
        control_sep_deg=args.control_sep_deg,
        n_controls=args.n_controls,
        control_radius_deg=args.control_radius_deg,
        control_pm_window_masyr=args.control_pm_window_masyr,
        control_parallax_halfwidth_mas=args.control_parallax_halfwidth_mas,
        bootstrap_iter=args.bootstrap_iter,
        isochrone_csv=args.isochrone_csv,
        completeness_csv=args.completeness_csv,
    )
    run(cfg, download_controls=args.download_controls, analyze=args.analyze)


if __name__ == "__main__":
    main()
