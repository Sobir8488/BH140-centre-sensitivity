#!/usr/bin/env python3
"""
previous_membership_pipeline.py

multi-survey multi-survey validation pipeline for BH 140.

Scientific goal
---------------
Build a reproducible, claim-gated analysis of BH 140 using:
  1. Gaia DR3 wide-field astrometry/photometry
  2. HST/MGCS astro-photometric catalogues and artificial-star tests via CDS/VizieR
  3. VVVX/VIRAC2 near-IR astrometry/photometry via ESO TAP_CAT
  4. WINERED spectroscopic radial-velocity table from the public paper/HTML tables
  5. Baumgardt/Vasiliev external parameters from Holger Baumgardt's database

Important notes
---------------
* This script is designed to be reproducible and auditable, not to hide weak claims.
* Public archive schemas can change. The code therefore performs schema discovery where possible.
* Some products may require archive-side row limits, local caching, or a manual URL if the service changes.
* The physical mass-function layer requires an official isochrone file supplied by the user.

Example
-------
python membership_pipeline.py \
    --ra-deg 193.25125 --dec-deg -67.174444 \
    --radius-deg 0.50 \
    --outdir results_BH140_multisurvey_validation \
    --download --analyze

Dependencies
------------
numpy, pandas, scipy, matplotlib, astropy, astroquery, pyvo, scikit-learn, requests, bs4, lxml, pyyaml
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import re
import sys
import site
_USER_SITE = site.getusersitepackages()
if _USER_SITE and _USER_SITE not in sys.path:
    sys.path.insert(0, _USER_SITE)
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import requests
from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.table import Table
from astropy.time import Time
from scipy import stats
from scipy.spatial import cKDTree

try:
    from astroquery.gaia import Gaia
except Exception:  # pragma: no cover
    Gaia = None

try:
    from astroquery.vizier import Vizier
except Exception:  # pragma: no cover
    Vizier = None

try:
    import pyvo
except Exception:  # pragma: no cover
    pyvo = None

try:
    from sklearn.mixture import GaussianMixture
    from sklearn.preprocessing import RobustScaler
except Exception:  # pragma: no cover
    GaussianMixture = None
    RobustScaler = None

import matplotlib.pyplot as plt

LOGGER = logging.getLogger("BH140-VALIDATION")


# ----------------------------- configuration ----------------------------- #

@dataclass
class Config:
    # BH 140 J2000 centre: 12:53:00.3, -67:10:28 from recent literature.
    ra_deg: float = 193.25125
    dec_deg: float = -67.174444
    radius_deg: float = 0.50
    outdir: str = "results_BH140_multisurvey_validation"

    # Adopted external parameters; revise when final literature table is frozen.
    distance_kpc: float = 4.81
    distance_err_kpc: float = 0.25
    pmra_lit: float = -14.8685
    pmdec_lit: float = 1.2164
    vlos_kms: float = 91.72
    vlos_err_kms: float = 1.92
    mass_msun: float = 6.1e4
    rh_pc: float = 9.73
    rgc_kpc: float = 6.86
    tidal_radius_pc_lit: float = 31.0

    # Quality and analysis thresholds.
    gaia_ruwe_max: float = 1.4
    gaia_vis_periods_min: int = 8
    p_mem_primary: float = 0.90
    p_mem_relaxed: float = 0.70
    p_mem_strict: float = 0.95

    # Anchored membership priors. These prevent an unsupervised GMM from selecting
    # the dominant foreground population in a very wide low-latitude Gaia cone.
    membership_mode: str = "anchored"  # anchored, gmm, or hybrid
    cluster_radius_prior_deg: float = 0.16
    pm_prior_sigma_masyr: float = 0.85
    parallax_prior_sigma_mas: float = 0.45
    membership_chi2_cut: float = 6.0
    membership_temperature: float = 1.5

    crossmatch_arcsec_gaia_hst: float = 0.20
    crossmatch_arcsec_gaia_virac: float = 0.35
    outer_quantile: float = 0.90
    bootstrap_n: int = 1000
    random_seed: int = 42

    # Remote services.
    mgcs_vizier_catalog: str = "J/A+A/709/A140"
    eso_tap_cat_url: str = "https://archive.eso.org/tap_cat"
    virac2_source_table: str = "VVVX_VIRAC_V2_SOURCES"
    baumgardt_url: str = "https://people.smp.uq.edu.au/HolgerBaumgardt/globular/fits/bh140.html"
    winered_url: str = "https://arxiv.org/html/2603.15450v1"

    # Optional local official isochrone file. Must include columns compatible with mass, mag, color.
    isochrone_csv: Optional[str] = None

    def paths(self) -> Dict[str, Path]:
        base = Path(self.outdir)
        return {
            "base": base,
            "raw": base / "data" / "raw",
            "processed": base / "data" / "processed",
            "figures": base / "figures",
            "tables": base / "tables",
            "logs": base / "logs",
        }


def setup_dirs(cfg: Config) -> None:
    for p in cfg.paths().values():
        p.mkdir(parents=True, exist_ok=True)


def save_table(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    LOGGER.info("Saved %s rows to %s", len(df), path)


def table_to_pandas(tab) -> pd.DataFrame:
    if tab is None:
        return pd.DataFrame()
    if isinstance(tab, pd.DataFrame):
        return tab.copy()
    if isinstance(tab, Table):
        return tab.to_pandas()
    try:
        return tab.to_table().to_pandas()
    except Exception:
        return pd.DataFrame(tab)


# ----------------------------- download clients ----------------------------- #

def download_gaia_dr3(cfg: Config) -> pd.DataFrame:
    """Download a Gaia DR3 cone search around BH 140."""
    if Gaia is None:
        raise RuntimeError("astroquery.gaia is not installed. Install astroquery.")

    query = f"""
    SELECT
        source_id, ra, dec, l, b,
        pmra, pmdec, pmra_error, pmdec_error, pmra_pmdec_corr,
        parallax, parallax_error,
        phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag,
        bp_rp, ruwe, visibility_periods_used, duplicated_source,
        astrometric_excess_noise, astrometric_params_solved,
        radial_velocity, radial_velocity_error,
        phot_bp_rp_excess_factor
    FROM gaiadr3.gaia_source
    WHERE 1=CONTAINS(
        POINT('ICRS', ra, dec),
        CIRCLE('ICRS', {cfg.ra_deg:.8f}, {cfg.dec_deg:.8f}, {cfg.radius_deg:.8f})
    )
    """
    LOGGER.info("Submitting Gaia DR3 ADQL query with radius %.3f deg", cfg.radius_deg)
    job = Gaia.launch_job_async(query, dump_to_file=False)
    df = table_to_pandas(job.get_results())
    save_table(df, cfg.paths()["raw"] / "gaia_dr3_bh140_cone.csv")
    return df


def download_baumgardt(cfg: Config) -> pd.DataFrame:
    """Parse Baumgardt BH140 page into a compact key-value table."""
    LOGGER.info("Downloading Baumgardt page: %s", cfg.baumgardt_url)
    r = requests.get(cfg.baumgardt_url, timeout=60)
    r.raise_for_status()
    html = r.text
    text = re.sub(r"\s+", " ", html)
    patterns = {
        "distance_pc": r"Distance from Sun:\s*([0-9]+)\s*[±&plusmn;]+\s*([0-9]+)\s*pc",
        "rgc_pc": r"Galactocentric distance:\s*([0-9]+)\s*[±&plusmn;]+\s*([0-9]+)\s*pc",
        "v_mag": r"V-band magnitude:\s*([0-9.]+)\s*[±&plusmn;]+\s*([0-9.]+)",
        "mass_msun_coeff": r"Mass:\s*([0-9.]+)\s*·\s*10\^\{?([0-9]+)\}?\s*M",
        "ml_ratio": r"M/L ratio:\s*([0-9.]+)\s*[±&plusmn;]+\s*([0-9.]+)",
        "rh_pc": r"Half-mass radius:\s*([0-9.]+)\s*pc",
        "mf_slope_alpha": r"Power-law MF slope:\s*α\s*=\s*([-+0-9.]+)\s*[±&plusmn;]+\s*([0-9.]+)",
    }
    rows = []
    for key, pat in patterns.items():
        m = re.search(pat, text)
        if not m:
            rows.append({"quantity": key, "value": np.nan, "error": np.nan, "source_url": cfg.baumgardt_url})
            continue
        groups = m.groups()
        if key == "mass_msun_coeff":
            val = float(groups[0]) * 10 ** int(groups[1])
            err = np.nan
        else:
            val = float(groups[0])
            err = float(groups[1]) if len(groups) > 1 else np.nan
        rows.append({"quantity": key, "value": val, "error": err, "source_url": cfg.baumgardt_url})
    df = pd.DataFrame(rows)
    save_table(df, cfg.paths()["raw"] / "baumgardt_bh140_parameters.csv")
    return df


def download_winered(cfg: Config) -> pd.DataFrame:
    """Extract available BH 140 rows from the public WINERED article HTML tables.

    The A&A/arXiv HTML conversion sometimes merges table columns. This routine saves all
    parsed tables and extracts rows containing 'BH 140'. For a final paper, verify the
    machine-readable table against the journal/CDS supplementary data if available.
    """
    LOGGER.info("Downloading WINERED article tables: %s", cfg.winered_url)
    tables = pd.read_html(cfg.winered_url)
    all_rows = []
    raw_dir = cfg.paths()["raw"] / "winered_tables"
    raw_dir.mkdir(parents=True, exist_ok=True)
    for i, tab in enumerate(tables):
        path = raw_dir / f"winered_html_table_{i:02d}.csv"
        tab.to_csv(path, index=False)
        mask = tab.astype(str).apply(lambda col: col.str.contains("BH 140", case=False, regex=False, na=False)).any(axis=1)
        if mask.any():
            tmp = tab.loc[mask].copy()
            tmp.insert(0, "html_table_index", i)
            all_rows.append(tmp)
    df = pd.concat(all_rows, ignore_index=True) if all_rows else pd.DataFrame()
    if df.empty:
        LOGGER.warning("No BH 140 rows found in WINERED parsed HTML tables. Check manually.")
    save_table(df, cfg.paths()["raw"] / "winered_bh140_extracted_rows.csv")
    return df


def download_mgcs_vizier(cfg: Config) -> Dict[str, pd.DataFrame]:
    """Query MGCS catalog around BH140 through VizieR/CDS.

    The catalogue is public at J/A+A/709/A140. Table names and column names can be
    discovered at runtime. Querying by region prevents accidental download of the full release.
    """
    if Vizier is None:
        raise RuntimeError("astroquery.vizier is not installed. Install astroquery.")
    Vizier.ROW_LIMIT = -1
    v = Vizier(columns=["**"], row_limit=-1)
    coord = SkyCoord(cfg.ra_deg, cfg.dec_deg, unit="deg")
    LOGGER.info("Querying MGCS/VizieR catalog %s around BH 140", cfg.mgcs_vizier_catalog)
    try:
        result = v.query_region(coord, radius=cfg.radius_deg * u.deg, catalog=cfg.mgcs_vizier_catalog)
    except Exception as exc:
        LOGGER.error("MGCS VizieR query failed: %s", exc)
        return {}
    out = {}
    for name, tab in zip(result.keys(), result.values()):
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(name))
        df = table_to_pandas(tab)
        out[str(name)] = df
        save_table(df, cfg.paths()["raw"] / "mgcs_vizier" / f"{safe}.csv")
    if not out:
        LOGGER.warning("MGCS query returned no tables for this cone. Check radius or catalogue ID.")
    return out


def _tap_query(service_url: str, adql: str, maxrec: Optional[int] = None):
    if pyvo is None:
        raise RuntimeError("pyvo is not installed. Install pyvo.")
    service = pyvo.dal.TAPService(service_url)
    return service.search(adql, maxrec=maxrec).to_table().to_pandas()


def _infer_radec_columns(columns: pd.DataFrame) -> Tuple[str, str]:
    names = [str(x) for x in columns["column_name"].tolist()]
    lower = {n.lower(): n for n in names}
    ra_candidates = ["ra", "raj2000", "ra2000", "alpha", "source_ra"]
    dec_candidates = ["dec", "de", "dej2000", "de2000", "delta", "source_dec", "declination"]
    ra_col = next((lower[c] for c in ra_candidates if c in lower), None)
    dec_col = next((lower[c] for c in dec_candidates if c in lower), None)
    if not ra_col or not dec_col:
        raise RuntimeError(f"Could not infer RA/Dec columns from {names[:30]} ...")
    return ra_col, dec_col


def download_virac2_eso(cfg: Config) -> pd.DataFrame:
    """Query VIRAC2 source catalogue through ESO TAP_CAT.

    ESO TAP_CAT sometimes rejects ADQL geometry predicates and, depending on
    backend settings, can also be fragile with BETWEEN clauses.  This version
    therefore uses a plain rectangular pre-selection with >= and <=, then applies
    the exact cone cut locally with astropy.  The declination column in VIRAC2 is
    usually named ``de`` rather than ``dec``.
    """
    LOGGER.info("Discovering VIRAC2 schema from ESO TAP_CAT")
    schema_q = f"""
    SELECT column_name, datatype, unit, ucd, description
    FROM TAP_SCHEMA.columns
    WHERE table_name = '{cfg.virac2_source_table}'
    """
    cols = _tap_query(cfg.eso_tap_cat_url, schema_q)
    if cols.empty:
        raise RuntimeError(f"No TAP_SCHEMA columns found for {cfg.virac2_source_table}")
    save_table(cols, cfg.paths()["raw"] / "virac2_schema_columns.csv")
    ra_col, dec_col = _infer_radec_columns(cols)

    available = set(cols["column_name"].astype(str).tolist())
    wanted = [ra_col, dec_col]
    for c in [
        "sourceid", "source_id", "objid", "ref_epoch",
        "pmra", "pmra_error", "pmde", "pmde_error", "pmdec", "pmdec_error",
        "parallax", "parallax_error", "uwe", "chisq",
        "phot_z_mean_mag", "phot_y_mean_mag", "phot_j_mean_mag",
        "phot_h_mean_mag", "phot_ks_mean_mag",
        "zmag", "ymag", "jmag", "hmag", "ksmag", "ks_mag", "k_mag",
        "astfit_epochs", "astfit_params", "duplicate"
    ]:
        if c in available and c not in wanted:
            wanted.append(c)
    select_cols = ", ".join(wanted)

    # Rectangular bounding box.  This is intentionally SQL-simple because ESO
    # TAP_CAT is backed by SQL Anywhere and may not accept all ADQL geometry forms.
    dec0 = float(cfg.dec_deg)
    ra0 = float(cfg.ra_deg)
    rad = float(cfg.radius_deg)
    cosdec = max(0.05, abs(math.cos(math.radians(dec0))))
    dra = rad / cosdec
    ra_min, ra_max = ra0 - dra, ra0 + dra
    dec_min, dec_max = dec0 - rad, dec0 + rad

    q = f"""
    SELECT TOP 500000 {select_cols}
    FROM {cfg.virac2_source_table}
    WHERE {ra_col} >= {ra_min:.8f}
      AND {ra_col} <= {ra_max:.8f}
      AND {dec_col} >= {dec_min:.8f}
      AND {dec_col} <= {dec_max:.8f}
    """
    LOGGER.info("Querying VIRAC2 rectangular preselection through ESO TAP_CAT")
    df = _tap_query(cfg.eso_tap_cat_url, q)
    if df.empty:
        save_table(df, cfg.paths()["raw"] / "virac2_bh140_cone.csv")
        return df

    # Exact cone cut performed locally.
    c0 = SkyCoord(cfg.ra_deg * u.deg, cfg.dec_deg * u.deg, frame="icrs")
    cc = SkyCoord(df[ra_col].astype(float).to_numpy() * u.deg,
                  df[dec_col].astype(float).to_numpy() * u.deg,
                  frame="icrs")
    sep_deg = cc.separation(c0).to_value(u.deg)
    df = df.loc[sep_deg <= cfg.radius_deg].copy()
    df["sep_deg"] = sep_deg[sep_deg <= cfg.radius_deg]
    save_table(df, cfg.paths()["raw"] / "virac2_bh140_cone.csv")
    return df


# ----------------------------- analysis utilities ----------------------------- #

def add_tangent_plane(df: pd.DataFrame, cfg: Config, ra_col="ra", dec_col="dec") -> pd.DataFrame:
    out = df.copy()
    c0 = SkyCoord(cfg.ra_deg * u.deg, cfg.dec_deg * u.deg, frame="icrs")
    c = SkyCoord(out[ra_col].to_numpy() * u.deg, out[dec_col].to_numpy() * u.deg, frame="icrs")
    dra, ddec = c0.spherical_offsets_to(c)
    out["x_deg"] = dra.to_value(u.deg)
    out["y_deg"] = ddec.to_value(u.deg)
    out["r_deg"] = np.hypot(out["x_deg"], out["y_deg"])
    out["r_pc"] = out["r_deg"] * np.pi / 180.0 * cfg.distance_kpc * 1000.0
    out["theta_rad"] = np.arctan2(out["y_deg"], out["x_deg"])
    return out


def gaia_quality_audit(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    out = df.copy()
    q = np.zeros(len(out), dtype=int)
    finite_ast = np.isfinite(out.get("pmra", np.nan)) & np.isfinite(out.get("pmdec", np.nan)) & np.isfinite(out.get("parallax", np.nan))
    good_ruwe = out.get("ruwe", np.inf).astype(float) < cfg.gaia_ruwe_max if "ruwe" in out else True
    good_vis = out.get("visibility_periods_used", 0).astype(float) >= cfg.gaia_vis_periods_min if "visibility_periods_used" in out else True
    not_dup = ~out.get("duplicated_source", False).astype(bool) if "duplicated_source" in out else True
    phot_ok = np.isfinite(out.get("phot_g_mean_mag", np.nan))
    q[finite_ast] = 1
    q[finite_ast & good_ruwe & good_vis & not_dup] = 2
    q[finite_ast & good_ruwe & good_vis & not_dup & phot_ok] = 3
    out["q_flag"] = q
    return out



def _logistic_from_score(score: np.ndarray, cut: float, temperature: float) -> np.ndarray:
    """Convert a chi-square-like score to a soft membership probability."""
    z = (np.asarray(score, dtype=float) - cut) / max(float(temperature), 1e-6)
    z = np.clip(z, -60, 60)
    return 1.0 / (1.0 + np.exp(z))


def fit_gaia_membership_gmm(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    """Unsupervised GMM membership probability.

    This mode is retained for comparison only. In a 0.5-deg low-latitude field it can
    choose the dominant foreground component unless externally anchored validation is
    applied. The publication-quality default is therefore the anchored mode below.
    """
    out = df.copy()
    features = []
    for col in ["x_deg", "y_deg", "pmra", "pmdec", "parallax"]:
        if col in out:
            features.append(col)
    if "bp_rp" in out:
        features.append("bp_rp")
    X = out[features].replace([np.inf, -np.inf], np.nan).dropna()
    out["p_mem_gmm"] = np.nan
    if len(X) < 50 or GaussianMixture is None or RobustScaler is None:
        LOGGER.warning("GMM unavailable or too few finite rows; p_mem_gmm left NaN.")
        return out

    scaler = RobustScaler()
    Z = scaler.fit_transform(X.to_numpy())
    best = None
    for k in [2, 3, 4, 5]:
        try:
            model = GaussianMixture(n_components=k, covariance_type="full", random_state=cfg.random_seed, n_init=5)
            model.fit(Z)
            bic = model.bic(Z)
            if best is None or bic < best[0]:
                best = (bic, model)
        except Exception:
            continue
    if best is None:
        LOGGER.warning("GMM membership fit failed; p_mem_gmm left NaN.")
        return out
    model = best[1]
    probs = model.predict_proba(Z)

    centres = pd.DataFrame(scaler.inverse_transform(model.means_), columns=features)
    score = np.zeros(len(centres), dtype=float)
    if "x_deg" in centres and "y_deg" in centres:
        score += (centres["x_deg"] / max(cfg.cluster_radius_prior_deg, 1e-6)) ** 2
        score += (centres["y_deg"] / max(cfg.cluster_radius_prior_deg, 1e-6)) ** 2
    if "pmra" in centres and "pmdec" in centres:
        score += ((centres["pmra"] - cfg.pmra_lit) / cfg.pm_prior_sigma_masyr) ** 2
        score += ((centres["pmdec"] - cfg.pmdec_lit) / cfg.pm_prior_sigma_masyr) ** 2
    if "parallax" in centres:
        score += ((centres["parallax"] - 1.0 / cfg.distance_kpc) / cfg.parallax_prior_sigma_mas) ** 2
    comp = int(np.argmin(score))
    out.loc[X.index, "p_mem_gmm"] = probs[:, comp]
    meta = {
        "features": features,
        "n_components": int(model.n_components),
        "bic": float(best[0]),
        "cluster_component": comp,
        "component_centres": centres.to_dict(orient="records"),
        "component_anchor_score": score.tolist(),
    }
    (cfg.paths()["processed"] / "gaia_membership_gmm_model.json").write_text(json.dumps(meta, indent=2))
    return out


def fit_gaia_membership_anchored(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    """Externally anchored Gaia membership probability for BH 140.

    The score is centred on the literature/spectroscopic systemic proper motion, the
    adopted-distance parallax, and the cluster centre. This avoids the main failure mode
    seen in the first run: a purely unsupervised model selected a foreground population
    with parallax around 1.4 mas and PM far from the BH 140 systemic motion.

    The output p_mem is a soft ranking variable for source selection, not a calibrated
    Bayesian posterior. It must be reported together with threshold-sensitivity tests.
    """
    out = df.copy()
    expected_plx = 1.0 / cfg.distance_kpc

    pmra = pd.to_numeric(out.get("pmra"), errors="coerce").to_numpy(float)
    pmdec = pd.to_numeric(out.get("pmdec"), errors="coerce").to_numpy(float)
    plx = pd.to_numeric(out.get("parallax"), errors="coerce").to_numpy(float)
    r = pd.to_numeric(out.get("r_deg"), errors="coerce").to_numpy(float)

    dpm2 = ((pmra - cfg.pmra_lit) / max(cfg.pm_prior_sigma_masyr, 1e-6)) ** 2
    dpm2 += ((pmdec - cfg.pmdec_lit) / max(cfg.pm_prior_sigma_masyr, 1e-6)) ** 2
    dplx2 = ((plx - expected_plx) / max(cfg.parallax_prior_sigma_mas, 1e-6)) ** 2
    dr2 = (r / max(cfg.cluster_radius_prior_deg, 1e-6)) ** 2

    score = dpm2 + dplx2 + dr2
    p_anchor = _logistic_from_score(score, cfg.membership_chi2_cut, cfg.membership_temperature)
    p_anchor[~np.isfinite(score)] = np.nan

    out["p_mem_anchor"] = p_anchor
    out["membership_score_anchor"] = score
    out["dpm_from_lit_masyr"] = np.hypot(pmra - cfg.pmra_lit, pmdec - cfg.pmdec_lit)
    out["dparallax_from_expected_mas"] = plx - expected_plx
    return out


def fit_gaia_membership(df: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    """Build the publication-facing p_mem column.

    Default: anchored membership. Optional gmm/hybrid modes are kept for sensitivity
    checks, but any run whose selected members fail the literature-PM/parallax sanity
    checks is automatically downgraded in the claim-audit table.
    """
    mode = str(getattr(cfg, "membership_mode", "anchored")).lower()
    out = fit_gaia_membership_anchored(df, cfg)
    if mode in {"gmm", "hybrid"}:
        out = fit_gaia_membership_gmm(out, cfg)
    if mode == "gmm" and "p_mem_gmm" in out:
        out["p_mem"] = out["p_mem_gmm"]
    elif mode == "hybrid" and "p_mem_gmm" in out:
        out["p_mem"] = np.sqrt(out["p_mem_anchor"].fillna(0) * out["p_mem_gmm"].fillna(0))
    else:
        out["p_mem"] = out["p_mem_anchor"]

    meta = {
        "membership_mode": mode,
        "pmra_lit": cfg.pmra_lit,
        "pmdec_lit": cfg.pmdec_lit,
        "expected_parallax_mas": 1.0 / cfg.distance_kpc,
        "cluster_radius_prior_deg": cfg.cluster_radius_prior_deg,
        "pm_prior_sigma_masyr": cfg.pm_prior_sigma_masyr,
        "parallax_prior_sigma_mas": cfg.parallax_prior_sigma_mas,
        "membership_chi2_cut": cfg.membership_chi2_cut,
        "membership_temperature": cfg.membership_temperature,
    }
    (cfg.paths()["processed"] / "gaia_membership_anchor_model.json").write_text(json.dumps(meta, indent=2))
    return out

def structural_diagnostics(members: pd.DataFrame, cfg: Config) -> Dict[str, float]:
    x = members["x_deg"].to_numpy(float)
    y = members["y_deg"].to_numpy(float)
    r = np.hypot(x, y)
    r50 = float(np.nanquantile(r, 0.50))
    r90 = float(np.nanquantile(r, cfg.outer_quantile))
    cov = np.cov(np.vstack([x, y]))
    evals, evecs = np.linalg.eigh(cov)
    evals = np.sort(evals)[::-1]
    ellipticity = float(1 - math.sqrt(max(evals[1], 0) / max(evals[0], 1e-12)))
    major_vec = evecs[:, np.argmax(np.linalg.eigvals(cov))]
    pa = float((np.degrees(np.arctan2(major_vec[1], major_vec[0])) + 360) % 180)
    return {
        "n": int(len(members)),
        "r50_deg": r50,
        "r50_pc": r50 * np.pi / 180 * cfg.distance_kpc * 1000,
        "r90_deg": r90,
        "r90_pc": r90 * np.pi / 180 * cfg.distance_kpc * 1000,
        "ellipticity": ellipticity,
        "ellipticity_pa_deg": pa,
    }


def rayleigh_test(theta: np.ndarray) -> Dict[str, float]:
    theta = np.asarray(theta, dtype=float)
    theta = theta[np.isfinite(theta)]
    n = len(theta)
    if n == 0:
        return {"n": 0, "rayleigh_R": np.nan, "rayleigh_p": np.nan, "pa_deg": np.nan}
    c = np.mean(np.cos(theta))
    s = np.mean(np.sin(theta))
    R = float(np.hypot(c, s))
    p = float(np.exp(-n * R * R))
    pa = float((np.degrees(np.arctan2(s, c)) + 360) % 180)
    return {"n": int(n), "rayleigh_R": R, "rayleigh_p": p, "pa_deg": pa}


def pm_components(members: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    out = members.copy()
    dmu_a = out["pmra"].to_numpy(float) - np.nanmedian(out["pmra"].to_numpy(float))
    dmu_d = out["pmdec"].to_numpy(float) - np.nanmedian(out["pmdec"].to_numpy(float))
    th = out["theta_rad"].to_numpy(float)
    mu_r = dmu_a * np.cos(th) + dmu_d * np.sin(th)
    mu_t = -dmu_a * np.sin(th) + dmu_d * np.cos(th)
    out["mu_r"] = mu_r
    out["mu_t"] = mu_t
    return out


def rotation_null_tests(members: pd.DataFrame, cfg: Config) -> Dict[str, float]:
    rng = np.random.default_rng(cfg.random_seed)
    mu_t = members["mu_t"].to_numpy(float)
    theta = members["theta_rad"].to_numpy(float)
    obs = float(np.nanmax(np.abs([np.nanmedian(mu_t[theta >= 0]), np.nanmedian(mu_t[theta < 0])])))
    b = max(200, min(cfg.bootstrap_n, 5000))
    null_flip = []
    null_angle = []
    for _ in range(b):
        signs = rng.choice([-1, 1], size=len(mu_t))
        mt = mu_t * signs
        null_flip.append(np.nanmax(np.abs([np.nanmedian(mt[theta >= 0]), np.nanmedian(mt[theta < 0])])))
        t2 = rng.permutation(theta)
        null_angle.append(np.nanmax(np.abs([np.nanmedian(mu_t[t2 >= 0]), np.nanmedian(mu_t[t2 < 0])])))
    p_flip = (1 + np.sum(np.asarray(null_flip) >= obs)) / (b + 1)
    p_angle = (1 + np.sum(np.asarray(null_angle) >= obs)) / (b + 1)
    return {"vrot_pm_peak_masyr": obs, "p_sign_flip": float(p_flip), "p_angle_scramble": float(p_angle), "n_null": int(b)}


def crossmatch(left: pd.DataFrame, right: pd.DataFrame, left_radec=("ra", "dec"), right_radec=("ra", "dec"), max_arcsec=0.3) -> pd.DataFrame:
    if left.empty or right.empty:
        return pd.DataFrame()
    c1 = SkyCoord(left[left_radec[0]].to_numpy() * u.deg, left[left_radec[1]].to_numpy() * u.deg)
    c2 = SkyCoord(right[right_radec[0]].to_numpy() * u.deg, right[right_radec[1]].to_numpy() * u.deg)
    idx, sep2d, _ = c1.match_to_catalog_sky(c2)
    ok = sep2d.arcsec <= max_arcsec
    l = left.loc[ok].reset_index(drop=True).add_prefix("left_")
    r = right.iloc[idx[ok]].reset_index(drop=True).add_prefix("right_")
    out = pd.concat([l, r], axis=1)
    out["sep_arcsec"] = sep2d.arcsec[ok]
    return out



def infer_radec_from_dataframe(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str]]:
    """Infer RA/Dec columns from common CDS/ESO/VizieR naming conventions."""
    if df is None or df.empty:
        return None, None
    cols = list(df.columns)
    lower = {str(c).lower(): str(c) for c in cols}
    ra_keys = ["ra", "raj2000", "ra_icrs", "_ra", "_ra.icrs", "alpha", "source_ra"]
    dec_keys = ["dec", "de", "dej2000", "de_icrs", "_de", "_de.icrs", "delta", "source_dec"]
    ra_col = next((lower[k] for k in ra_keys if k in lower), None)
    dec_col = next((lower[k] for k in dec_keys if k in lower), None)
    if ra_col and dec_col:
        return ra_col, dec_col
    # Last resort: substring matching, avoiding error columns.
    for c in cols:
        lc = str(c).lower()
        if ra_col is None and (lc == "ra" or lc.endswith("ra") or "ra.icrs" in lc) and "error" not in lc and "corr" not in lc:
            ra_col = str(c)
        if dec_col is None and (lc in {"de", "dec"} or lc.endswith("dec") or lc.endswith("de") or "de.icrs" in lc) and "error" not in lc and "corr" not in lc:
            dec_col = str(c)
    return ra_col, dec_col


def membership_sanity_flags(summary: Dict[str, float], cfg: Config) -> Dict[str, object]:
    """Sanity checks that prevent foreground selections from being used as BH 140 results."""
    pm_offset = float(np.hypot(summary.get("pmra_med", np.nan) - cfg.pmra_lit,
                               summary.get("pmdec_med", np.nan) - cfg.pmdec_lit))
    plx_offset = float(abs(summary.get("parallax_med", np.nan) - 1.0 / cfg.distance_kpc))
    r90 = float(summary.get("r90_deg", np.nan))
    failed = []
    if not np.isfinite(pm_offset) or pm_offset > 0.75:
        failed.append("median proper motion is inconsistent with the BH 140 literature value")
    if not np.isfinite(plx_offset) or plx_offset > 0.60:
        failed.append("median parallax is inconsistent with the adopted BH 140 distance")
    if not np.isfinite(r90) or r90 > 0.30:
        failed.append("R90 is too large for the anchored BH 140 member population")
    return {
        "membership_pm_offset_masyr": pm_offset,
        "membership_parallax_offset_mas": plx_offset,
        "membership_sanity_pass": len(failed) == 0,
        "membership_sanity_failures": "; ".join(failed),
    }


def fit_mass_proxy_from_isochrone(phot: pd.DataFrame, cfg: Config, mag_col: str, color_col: str) -> pd.DataFrame:
    """Nearest-neighbour mass proxy using a user-supplied official isochrone CSV.

    Required isochrone columns: mass, mag, color. The user should create mag/color in the
    same filter system and extinction solution before running this function.
    """
    out = phot.copy()
    out["mass_proxy"] = np.nan
    if not cfg.isochrone_csv:
        LOGGER.warning("No --isochrone-csv supplied; mass_proxy left as NaN.")
        return out
    iso = pd.read_csv(cfg.isochrone_csv)
    required = {"mass", "mag", "color"}
    if not required.issubset(iso.columns):
        raise ValueError(f"Isochrone file must contain columns {required}")
    finite = out[[mag_col, color_col]].replace([np.inf, -np.inf], np.nan).dropna()
    tree = cKDTree(iso[["mag", "color"]].to_numpy(float))
    dist, idx = tree.query(finite[[mag_col, color_col]].to_numpy(float), k=1)
    out.loc[finite.index, "mass_proxy"] = iso.iloc[idx]["mass"].to_numpy(float)
    out.loc[finite.index, "iso_cmd_dist"] = dist
    return out


def claim_audit(summary: Dict[str, float]) -> pd.DataFrame:
    rows = []
    rows.append({
        "claim": "Gaia wide-field membership",
        "evidence": "GMM/source-level Gaia DR3 member population and quality audit",
        "level": "secure" if summary.get("n_primary", 0) >= 100 and summary.get("membership_sanity_pass", False) else "failed/needs revision",
        "required_upgrade": "Report model family, priors, threshold sensitivity, and full source table",
    })
    rows.append({
        "claim": "Outer anisotropy / tidal structure",
        "evidence": f"Rayleigh p={summary.get('outer_rayleigh_p', np.nan):.4g}",
        "level": "candidate" if summary.get("outer_rayleigh_p", 1) < 0.05 else "unsupported",
        "required_upgrade": "Matched control fields; PM coherence; NIR/HST CMD consistency; orbit alignment",
    })
    rows.append({
        "claim": "Internal rotation",
        "evidence": f"sign-flip p={summary.get('p_sign_flip', np.nan):.4g}; angle p={summary.get('p_angle_scramble', np.nan):.4g}",
        "level": "secure" if summary.get("p_sign_flip", 1) < 0.01 and summary.get("p_angle_scramble", 1) < 0.01 else "not claimed",
        "required_upgrade": "Stable rotation-axis scan and RV gradient confirmation",
    })
    rows.append({
        "claim": "Physical lower-MS mass function",
        "evidence": "Requires HST/MGCS completeness and official isochrone grid",
        "level": "externally supported" if summary.get("has_hst", False) and summary.get("has_isochrone", False) else "candidate/not claimed",
        "required_upgrade": "Artificial-star completeness C(m,R), PARSEC/MIST/BaSTI sensitivity, binary/reddening audit",
    })
    rows.append({
        "claim": "Orbit/origin class",
        "evidence": "Requires consistent D, PM, RV and coordinate convention",
        "level": "externally supported" if summary.get("has_winered", False) else "not claimed",
        "required_upgrade": "Monte Carlo orbit with documented Galactic potential and solar parameters",
    })
    return pd.DataFrame(rows)


# ----------------------------- plotting ----------------------------- #

def plot_gaia_overview(members: pd.DataFrame, cfg: Config) -> None:
    figdir = cfg.paths()["figures"]
    plt.figure(figsize=(6, 5))
    plt.scatter(members["x_deg"], members["y_deg"], s=2, alpha=0.5)
    plt.xlabel(r"$\Delta\alpha^\ast$ [deg]")
    plt.ylabel(r"$\Delta\delta$ [deg]")
    plt.title("BH 140 Gaia DR3 primary members")
    plt.gca().set_aspect("equal", adjustable="box")
    plt.tight_layout()
    plt.savefig(figdir / "BH140_gaia_members_sky.png", dpi=200)
    plt.close()

    plt.figure(figsize=(6, 5))
    if "phot_g_mean_mag" in members and "bp_rp" in members:
        plt.scatter(members["bp_rp"], members["phot_g_mean_mag"], s=2, alpha=0.4)
        plt.gca().invert_yaxis()
        plt.xlabel(r"$G_{BP}-G_{RP}$")
        plt.ylabel(r"$G$")
        plt.title("BH 140 Gaia CMD")
        plt.tight_layout()
        plt.savefig(figdir / "BH140_gaia_cmd.png", dpi=200)
    plt.close()


# ----------------------------- pipeline ----------------------------- #

def load_or_download(cfg: Config, download: bool) -> Dict[str, object]:
    raw = cfg.paths()["raw"]
    data: Dict[str, object] = {}

    gaia_path = raw / "gaia_dr3_bh140_cone.csv"
    if download or not gaia_path.exists():
        data["gaia"] = download_gaia_dr3(cfg)
    else:
        data["gaia"] = pd.read_csv(gaia_path)

    try:
        b_path = raw / "baumgardt_bh140_parameters.csv"
        data["baumgardt"] = download_baumgardt(cfg) if download or not b_path.exists() else pd.read_csv(b_path)
    except Exception as exc:
        LOGGER.warning("Baumgardt download failed: %s", exc)
        data["baumgardt"] = pd.DataFrame()

    try:
        w_path = raw / "winered_bh140_extracted_rows.csv"
        data["winered"] = download_winered(cfg) if download or not w_path.exists() else pd.read_csv(w_path)
    except Exception as exc:
        LOGGER.warning("WINERED download/parse failed: %s", exc)
        data["winered"] = pd.DataFrame()

    try:
        mgcs_dir = raw / "mgcs_vizier"
        if download or not mgcs_dir.exists() or not list(mgcs_dir.glob("*.csv")):
            data["mgcs"] = download_mgcs_vizier(cfg)
        else:
            data["mgcs"] = {p.stem: pd.read_csv(p) for p in mgcs_dir.glob("*.csv")}
    except Exception as exc:
        LOGGER.warning("MGCS download/query failed: %s", exc)
        data["mgcs"] = {}

    try:
        v_path = raw / "virac2_bh140_cone.csv"
        data["virac2"] = download_virac2_eso(cfg) if download or not v_path.exists() else pd.read_csv(v_path)
    except Exception as exc:
        LOGGER.warning("VIRAC2 download/query failed: %s", exc)
        data["virac2"] = pd.DataFrame()

    return data


def analyze(cfg: Config, data: Dict[str, object]) -> None:
    proc = cfg.paths()["processed"]
    tabs = cfg.paths()["tables"]

    gaia = data.get("gaia", pd.DataFrame())
    if not isinstance(gaia, pd.DataFrame) or gaia.empty:
        raise RuntimeError("Gaia table is required for baseline analysis.")

    gaia = add_tangent_plane(gaia, cfg)
    gaia = gaia_quality_audit(gaia, cfg)
    gaia = fit_gaia_membership(gaia, cfg)
    save_table(gaia, proc / "gaia_dr3_with_membership.csv")

    primary = gaia[(gaia["p_mem"] >= cfg.p_mem_primary) & (gaia["q_flag"] >= 2)].copy()
    relaxed = gaia[(gaia["p_mem"] >= cfg.p_mem_relaxed) & (gaia["q_flag"] >= 2)].copy()
    strict = gaia[(gaia["p_mem"] >= cfg.p_mem_strict) & (gaia["q_flag"] >= 2)].copy()
    save_table(primary, proc / "gaia_primary_members.csv")

    struct = structural_diagnostics(primary, cfg)
    primary_pm = pm_components(primary, cfg)
    rot = rotation_null_tests(primary_pm, cfg) if len(primary_pm) > 20 else {}

    r90 = struct["r90_deg"]
    outer = primary_pm[primary_pm["r_deg"] > r90].copy()
    outer_test = rayleigh_test(outer["theta_rad"].to_numpy())
    save_table(outer, proc / "gaia_outer_candidates.csv")

    summary = {
        **struct,
        **rot,
        "n_parent": int(len(gaia)),
        "n_primary": int(len(primary)),
        "n_relaxed": int(len(relaxed)),
        "n_strict": int(len(strict)),
        "pmra_med": float(np.nanmedian(primary["pmra"])),
        "pmdec_med": float(np.nanmedian(primary["pmdec"])),
        "parallax_med": float(np.nanmedian(primary["parallax"])),
        "expected_parallax_mas": 1.0 / cfg.distance_kpc,
        "outer_n": int(len(outer)),
        "outer_rayleigh_R": outer_test["rayleigh_R"],
        "outer_rayleigh_p": outer_test["rayleigh_p"],
        "outer_pa_deg": outer_test["pa_deg"],
        "has_hst": bool(data.get("mgcs")),
        "has_winered": isinstance(data.get("winered"), pd.DataFrame) and not data.get("winered").empty,
        "has_virac2": isinstance(data.get("virac2"), pd.DataFrame) and not data.get("virac2").empty,
        "has_isochrone": bool(cfg.isochrone_csv),
    }
    summary.update(membership_sanity_flags(summary, cfg))
    if not summary.get("membership_sanity_pass", False):
        LOGGER.warning("Membership sanity check failed: %s", summary.get("membership_sanity_failures"))
    (tabs / "BH140_summary.json").write_text(json.dumps(summary, indent=2))

    audit = claim_audit(summary)
    save_table(audit, tabs / "BH140_claim_audit.csv")
    save_table(pd.DataFrame([summary]), tabs / "BH140_summary_table.csv")
    plot_gaia_overview(primary, cfg)

    # Optional crossmatches.
    virac = data.get("virac2", pd.DataFrame())
    if isinstance(virac, pd.DataFrame) and not virac.empty:
        ra_v, dec_v = infer_radec_from_dataframe(virac)
        if ra_v and dec_v:
            m = crossmatch(primary, virac, ("ra", "dec"), (ra_v, dec_v), cfg.crossmatch_arcsec_gaia_virac)
            save_table(m, proc / "crossmatch_gaia_virac2_primary.csv")
        else:
            LOGGER.warning("Could not infer VIRAC2 RA/Dec columns for crossmatch.")

    mgcs = data.get("mgcs", {})
    if isinstance(mgcs, dict) and mgcs:
        for name, tab in mgcs.items():
            if not isinstance(tab, pd.DataFrame) or tab.empty:
                continue
            ra_col, dec_col = infer_radec_from_dataframe(tab)
            if ra_col and dec_col:
                m = crossmatch(primary, tab, ("ra", "dec"), (ra_col, dec_col), cfg.crossmatch_arcsec_gaia_hst)
                safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
                save_table(m, proc / f"crossmatch_gaia_mgcs_{safe}.csv")
            else:
                LOGGER.info("Skipping MGCS table %s because RA/Dec columns were not inferred.", name)

    LOGGER.info("Analysis complete. Key summary: %s", json.dumps(summary, indent=2))


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="BH 140 publication-level multi-survey validation pipeline")
    p.add_argument("--ra-deg", type=float, default=Config.ra_deg)
    p.add_argument("--dec-deg", type=float, default=Config.dec_deg)
    p.add_argument("--radius-deg", type=float, default=Config.radius_deg)
    p.add_argument("--outdir", type=str, default=Config.outdir)
    p.add_argument("--isochrone-csv", type=str, default=None)
    p.add_argument("--membership-mode", default=Config.membership_mode, choices=["anchored", "gmm", "hybrid"])
    p.add_argument("--cluster-radius-prior-deg", type=float, default=Config.cluster_radius_prior_deg)
    p.add_argument("--pm-prior-sigma-masyr", type=float, default=Config.pm_prior_sigma_masyr)
    p.add_argument("--parallax-prior-sigma-mas", type=float, default=Config.parallax_prior_sigma_mas)
    p.add_argument("--download", action="store_true", help="Force online queries/downloads instead of cached files")
    p.add_argument("--analyze", action="store_true", help="Run analysis after download/cache load")
    p.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    p.add_argument("--mgcs-vizier-catalog", default=Config.mgcs_vizier_catalog)
    p.add_argument("--eso-tap-cat-url", default=Config.eso_tap_cat_url)
    p.add_argument("--virac2-source-table", default=Config.virac2_source_table)
    p.add_argument("--winered-url", default=Config.winered_url)
    p.add_argument("--baumgardt-url", default=Config.baumgardt_url)
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = Config(
        ra_deg=args.ra_deg,
        dec_deg=args.dec_deg,
        radius_deg=args.radius_deg,
        outdir=args.outdir,
        isochrone_csv=args.isochrone_csv,
        membership_mode=args.membership_mode,
        cluster_radius_prior_deg=args.cluster_radius_prior_deg,
        pm_prior_sigma_masyr=args.pm_prior_sigma_masyr,
        parallax_prior_sigma_mas=args.parallax_prior_sigma_mas,
        mgcs_vizier_catalog=args.mgcs_vizier_catalog,
        eso_tap_cat_url=args.eso_tap_cat_url,
        virac2_source_table=args.virac2_source_table,
        winered_url=args.winered_url,
        baumgardt_url=args.baumgardt_url,
    )
    setup_dirs(cfg)
    (cfg.paths()["base"] / "config_used.json").write_text(json.dumps(asdict(cfg), indent=2))
    data = load_or_download(cfg, download=args.download)
    if args.analyze:
        analyze(cfg, data)
    else:
        LOGGER.info("Downloaded/loaded data only. Add --analyze to run diagnostics.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
