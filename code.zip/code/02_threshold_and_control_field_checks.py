#!/usr/bin/env python3
"""
bh140_outer_validation_v4.py

Post-processing validation module for BH 140 outer-member anisotropy.

This script is intended to be run AFTER 01_build_membership_catalog.py.
It adds the three claim-gated validation layers that are needed before the
outer-anisotropy signal can be interpreted physically:

1) Matched Gaia control fields
2) Threshold-stability matrix
3) Independent photometric/NIR availability diagnostics

It does NOT claim a confirmed tidal tail automatically.  It outputs claim-gated
CSV tables and compact diagnostic plots that you can cite in a manuscript.

Example in Spyder/IPython:
%run "C:/Users/USER/Desktop/BH_140/bh140_outer_validation_v4.py" --outdir "C:/Users/USER/Desktop/BH_140/results_BH140_multisurvey_validation_v3" --download-controls --analyze

Dependencies:
numpy, pandas, scipy, matplotlib, astropy, astroquery, pyvo
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import sys
import site
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

_USER_SITE = site.getusersitepackages()
if _USER_SITE and _USER_SITE not in sys.path:
    sys.path.insert(0, _USER_SITE)

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from astropy import units as u
from astropy.coordinates import SkyCoord

try:
    from astroquery.gaia import Gaia
except Exception:  # pragma: no cover
    Gaia = None

try:
    import pyvo
except Exception:  # pragma: no cover
    pyvo = None

import matplotlib.pyplot as plt

LOGGER = logging.getLogger("BH140-OUTER-V4")


@dataclass
class Config:
    # BH 140 adopted centre and external parameters.
    ra_deg: float = 193.25125
    dec_deg: float = -67.174444
    radius_deg: float = 0.50
    outdir: str = "results_BH140_multisurvey_validation_v3"
    distance_kpc: float = 4.81
    pmra_lit: float = -14.8685
    pmdec_lit: float = 1.2164
    parallax_exp_mas: float = 1.0 / 4.81

    # Anchored-membership parameters; keep consistent with the v3 run.
    cluster_radius_prior_deg: float = 0.16
    pm_prior_sigma_masyr: float = 0.85
    parallax_prior_sigma_mas: float = 0.45
    membership_temperature: float = 1.5

    # Gaia quality cuts.
    gaia_ruwe_max: float = 1.4
    gaia_vis_periods_min: int = 8

    # Control-field design.
    control_sep_deg: float = 1.75
    n_controls: int = 8
    control_pm_window_masyr: float = 3.5
    control_parallax_min_mas: float = -1.0
    control_parallax_max_mas: float = 1.5

    # Threshold-stability grid.
    p_thresholds: str = "0.80,0.85,0.90,0.95"
    outer_quantiles: str = "0.80,0.85,0.90,0.95"
    pm_sigmas: str = "0.70,0.85,1.00"
    parallax_sigmas: str = "0.35,0.45,0.60"
    quality_modes: str = "baseline,strict"

    # VIRAC2 footprint diagnostics.
    eso_tap_cat_url: str = "https://archive.eso.org/tap_cat"
    virac2_source_table: str = "VVVX_VIRAC_V2_SOURCES"
    virac2_radii: str = "0.05,0.10,0.25,0.50,1.00,1.50,2.00,2.25,2.50,2.75,3.00"

    # Randomness.
    random_seed: int = 42

    def paths(self) -> Dict[str, Path]:
        base = Path(self.outdir)
        return {
            "base": base,
            "raw": base / "data" / "raw",
            "processed": base / "data" / "processed",
            "control_raw": base / "data" / "raw" / "gaia_control_fields",
            "control_processed": base / "data" / "processed" / "gaia_control_fields",
            "tables": base / "tables",
            "figures": base / "figures",
        }


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def setup_dirs(cfg: Config) -> None:
    for p in cfg.paths().values():
        p.mkdir(parents=True, exist_ok=True)


def csv_write(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    LOGGER.info("Saved %s rows to %s", len(df), path)


def parse_float_list(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_str_list(s: str) -> List[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


# -------------------------------------------------------------------------
# Coordinate helpers
# -------------------------------------------------------------------------

def tangent_offsets_deg(df: pd.DataFrame, ra0: float, dec0: float,
                        ra_col: str = "ra", dec_col: str = "dec") -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    ra = pd.to_numeric(df[ra_col], errors="coerce").to_numpy(float)
    dec = pd.to_numeric(df[dec_col], errors="coerce").to_numpy(float)
    cosd = math.cos(math.radians(dec0))
    x = (ra - ra0) * cosd
    y = dec - dec0
    r = np.sqrt(x * x + y * y)
    return x, y, r


def position_angles_rad(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    theta = np.arctan2(y, x)
    theta = np.mod(theta, 2.0 * np.pi)
    return theta


def rayleigh_m(theta: np.ndarray, m: int = 1) -> Tuple[float, float, float]:
    theta = np.asarray(theta, dtype=float)
    theta = theta[np.isfinite(theta)]
    n = theta.size
    if n < 3:
        return np.nan, np.nan, np.nan
    c = np.sum(np.cos(m * theta))
    s = np.sum(np.sin(m * theta))
    R = np.sqrt(c * c + s * s) / n
    # Large-sample Rayleigh approximation.  The same approximation applies
    # after mapping theta -> m theta under the uniform null.
    p = float(np.exp(-n * R * R))
    pa = np.degrees(np.arctan2(s, c) / m) % (180.0 if m == 2 else 360.0)
    return float(R), p, float(pa)


def ellipticity_pa(x: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    good = np.isfinite(x) & np.isfinite(y)
    x = x[good]
    y = y[good]
    if x.size < 3:
        return np.nan, np.nan
    C = np.cov(np.vstack([x, y]))
    vals, vecs = np.linalg.eigh(C)
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    vec = vecs[:, order[0]]
    if vals[0] <= 0 or vals[1] < 0:
        return np.nan, np.nan
    e = 1.0 - math.sqrt(vals[1] / vals[0])
    pa = math.degrees(math.atan2(vec[1], vec[0])) % 180.0
    return float(e), float(pa)


# -------------------------------------------------------------------------
# Membership and quality
# -------------------------------------------------------------------------

def finite_col(df: pd.DataFrame, name: str) -> np.ndarray:
    if name not in df.columns:
        return np.zeros(len(df), dtype=bool)
    return np.isfinite(pd.to_numeric(df[name], errors="coerce").to_numpy(float))


def quality_mask(df: pd.DataFrame, mode: str, cfg: Config) -> np.ndarray:
    mask = np.ones(len(df), dtype=bool)
    # Finite core Gaia columns.
    for col in ["ra", "dec", "pmra", "pmdec", "parallax"]:
        if col in df.columns:
            mask &= finite_col(df, col)
    if "duplicated_source" in df.columns:
        dup = df["duplicated_source"]
        if dup.dtype == bool:
            mask &= ~dup.to_numpy(bool)
        else:
            mask &= ~dup.astype(str).str.lower().isin(["true", "1", "t"]).to_numpy()
    if "ruwe" in df.columns:
        ruwe = pd.to_numeric(df["ruwe"], errors="coerce").to_numpy(float)
        ruwe_limit = 1.2 if mode == "strict" else cfg.gaia_ruwe_max
        mask &= np.isfinite(ruwe) & (ruwe <= ruwe_limit)
    if "visibility_periods_used" in df.columns:
        vis = pd.to_numeric(df["visibility_periods_used"], errors="coerce").to_numpy(float)
        vis_min = 10 if mode == "strict" else cfg.gaia_vis_periods_min
        mask &= np.isfinite(vis) & (vis >= vis_min)
    return mask


def anchored_membership(df: pd.DataFrame, ra0: float, dec0: float, cfg: Config,
                        pm_sigma: Optional[float] = None,
                        parallax_sigma: Optional[float] = None,
                        radius_prior_deg: Optional[float] = None) -> pd.DataFrame:
    out = df.copy()
    pm_sigma = cfg.pm_prior_sigma_masyr if pm_sigma is None else pm_sigma
    parallax_sigma = cfg.parallax_prior_sigma_mas if parallax_sigma is None else parallax_sigma
    radius_prior_deg = cfg.cluster_radius_prior_deg if radius_prior_deg is None else radius_prior_deg

    x, y, r = tangent_offsets_deg(out, ra0, dec0, "ra", "dec")
    pmra = pd.to_numeric(out.get("pmra"), errors="coerce").to_numpy(float)
    pmdec = pd.to_numeric(out.get("pmdec"), errors="coerce").to_numpy(float)
    plx = pd.to_numeric(out.get("parallax"), errors="coerce").to_numpy(float)

    chi2 = (
        (x / radius_prior_deg) ** 2
        + (y / radius_prior_deg) ** 2
        + ((pmra - cfg.pmra_lit) / pm_sigma) ** 2
        + ((pmdec - cfg.pmdec_lit) / pm_sigma) ** 2
        + ((plx - cfg.parallax_exp_mas) / parallax_sigma) ** 2
    )
    p = np.exp(-0.5 * chi2 / cfg.membership_temperature)
    p[~np.isfinite(p)] = 0.0
    out["x_deg"] = x
    out["y_deg"] = y
    out["r_deg"] = r
    out["theta_rad"] = position_angles_rad(x, y)
    out["p_mem_anchor_v4"] = p
    return out


def summarize_selection(df: pd.DataFrame, selected: np.ndarray, ra0: float, dec0: float,
                        p_threshold: float, outer_q: float, quality: str,
                        pm_sigma: float, parallax_sigma: float,
                        field_id: str, field_kind: str) -> Dict[str, float | str]:
    sub = df.loc[selected].copy()
    result: Dict[str, float | str] = {
        "field_id": field_id,
        "field_kind": field_kind,
        "p_threshold": p_threshold,
        "outer_quantile": outer_q,
        "quality_mode": quality,
        "pm_sigma_masyr": pm_sigma,
        "parallax_sigma_mas": parallax_sigma,
        "n_selected": int(len(sub)),
        "n_outer": 0,
        "r50_deg": np.nan,
        "r90_deg": np.nan,
        "r_outer_threshold_deg": np.nan,
        "r50_pc": np.nan,
        "r90_pc": np.nan,
        "ellipticity": np.nan,
        "ellipticity_pa_deg": np.nan,
        "rayleigh_R1": np.nan,
        "rayleigh_p1": np.nan,
        "rayleigh_pa1_deg": np.nan,
        "axial_R2": np.nan,
        "axial_p2": np.nan,
        "axial_pa2_deg": np.nan,
        "pmra_med": np.nan,
        "pmdec_med": np.nan,
        "parallax_med": np.nan,
    }
    if len(sub) < 10:
        return result
    r = pd.to_numeric(sub["r_deg"], errors="coerce").to_numpy(float)
    x = pd.to_numeric(sub["x_deg"], errors="coerce").to_numpy(float)
    y = pd.to_numeric(sub["y_deg"], errors="coerce").to_numpy(float)
    result["r50_deg"] = float(np.nanquantile(r, 0.50))
    result["r90_deg"] = float(np.nanquantile(r, 0.90))
    result["r50_pc"] = float(result["r50_deg"] * math.pi / 180.0 * 4.81e3)
    result["r90_pc"] = float(result["r90_deg"] * math.pi / 180.0 * 4.81e3)
    e, epa = ellipticity_pa(x, y)
    result["ellipticity"] = e
    result["ellipticity_pa_deg"] = epa
    result["pmra_med"] = float(np.nanmedian(pd.to_numeric(sub["pmra"], errors="coerce")))
    result["pmdec_med"] = float(np.nanmedian(pd.to_numeric(sub["pmdec"], errors="coerce")))
    result["parallax_med"] = float(np.nanmedian(pd.to_numeric(sub["parallax"], errors="coerce")))

    rq = float(np.nanquantile(r, outer_q))
    result["r_outer_threshold_deg"] = rq
    outer = sub.loc[r > rq]
    result["n_outer"] = int(len(outer))
    if len(outer) >= 5:
        theta = pd.to_numeric(outer["theta_rad"], errors="coerce").to_numpy(float)
        R1, p1, pa1 = rayleigh_m(theta, m=1)
        R2, p2, pa2 = rayleigh_m(theta, m=2)
        result["rayleigh_R1"] = R1
        result["rayleigh_p1"] = p1
        result["rayleigh_pa1_deg"] = pa1
        result["axial_R2"] = R2
        result["axial_p2"] = p2
        result["axial_pa2_deg"] = pa2
    return result


# -------------------------------------------------------------------------
# Gaia download for matched control fields
# -------------------------------------------------------------------------

def control_centres(cfg: Config) -> pd.DataFrame:
    target = SkyCoord(ra=cfg.ra_deg * u.deg, dec=cfg.dec_deg * u.deg, frame="icrs")
    l0 = target.galactic.l.deg
    b0 = target.galactic.b.deg
    # Matched low-latitude controls around a ring in Galactic coordinates.
    # The centres are outside the target cone and are symmetric enough for
    # field artefact testing.  The user should inspect them for known clusters.
    phis = np.linspace(0, 2 * np.pi, cfg.n_controls, endpoint=False)
    rows = []
    for i, phi in enumerate(phis, start=1):
        dl = cfg.control_sep_deg * math.cos(phi)
        db = cfg.control_sep_deg * math.sin(phi) * 0.55  # keep latitude reasonably matched
        cc = SkyCoord(l=(l0 + dl) * u.deg, b=(b0 + db) * u.deg, frame="galactic").icrs
        rows.append({
            "field_id": f"CTRL_{i:02d}",
            "ra_deg": float(cc.ra.deg),
            "dec_deg": float(cc.dec.deg),
            "l_deg": float((l0 + dl) % 360.0),
            "b_deg": float(b0 + db),
            "separation_design_deg": cfg.control_sep_deg,
        })
    df = pd.DataFrame(rows)
    csv_write(df, cfg.paths()["tables"] / "BH140_control_field_centres.csv")
    return df


def gaia_control_query(cfg: Config, ra: float, dec: float) -> str:
    # PM/parallax prefilter reduces server load while preserving BH140-like contaminants.
    pmra_min = cfg.pmra_lit - cfg.control_pm_window_masyr
    pmra_max = cfg.pmra_lit + cfg.control_pm_window_masyr
    pmde_min = cfg.pmdec_lit - cfg.control_pm_window_masyr
    pmde_max = cfg.pmdec_lit + cfg.control_pm_window_masyr
    return f"""
    SELECT
        source_id, ra, dec, l, b,
        pmra, pmdec, pmra_error, pmdec_error, pmra_pmdec_corr,
        parallax, parallax_error,
        phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag,
        bp_rp, ruwe, visibility_periods_used, duplicated_source,
        astrometric_excess_noise, astrometric_params_solved,
        phot_bp_rp_excess_factor
    FROM gaiadr3.gaia_source
    WHERE 1=CONTAINS(
        POINT('ICRS', ra, dec),
        CIRCLE('ICRS', {ra:.8f}, {dec:.8f}, {cfg.radius_deg:.8f})
    )
      AND pmra BETWEEN {pmra_min:.6f} AND {pmra_max:.6f}
      AND pmdec BETWEEN {pmde_min:.6f} AND {pmde_max:.6f}
      AND parallax BETWEEN {cfg.control_parallax_min_mas:.6f} AND {cfg.control_parallax_max_mas:.6f}
    """


def download_control_fields(cfg: Config, centres: pd.DataFrame) -> None:
    if Gaia is None:
        raise RuntimeError("astroquery.gaia is not available.")
    for _, row in centres.iterrows():
        fid = row["field_id"]
        path = cfg.paths()["control_raw"] / f"{fid}_gaia_dr3_control.csv"
        if path.exists():
            LOGGER.info("Control field %s already exists; skipping download", fid)
            continue
        LOGGER.info("Downloading Gaia control field %s", fid)
        q = gaia_control_query(cfg, float(row["ra_deg"]), float(row["dec_deg"]))
        job = Gaia.launch_job_async(q, dump_to_file=False)
        tab = job.get_results()
        df = tab.to_pandas()
        csv_write(df, path)


# -------------------------------------------------------------------------
# VIRAC2 footprint diagnostics
# -------------------------------------------------------------------------

def virac2_rect_count(svc, table: str, ra0: float, dec0: float, radius_deg: float) -> int:
    dra = radius_deg / max(math.cos(math.radians(dec0)), 0.05)
    q = f"""
    SELECT COUNT(*) AS n
    FROM {table}
    WHERE ra >= {ra0 - dra:.8f}
      AND ra <= {ra0 + dra:.8f}
      AND de >= {dec0 - radius_deg:.8f}
      AND de <= {dec0 + radius_deg:.8f}
    """
    res = svc.search(q).to_table().to_pandas()
    return int(res["n"].iloc[0])


def virac2_footprint_diagnostic(cfg: Config) -> pd.DataFrame:
    if pyvo is None:
        LOGGER.warning("pyvo unavailable; skipping VIRAC2 footprint diagnostic")
        return pd.DataFrame()
    svc = pyvo.dal.TAPService(cfg.eso_tap_cat_url)
    rows = []
    for r in parse_float_list(cfg.virac2_radii):
        try:
            n = virac2_rect_count(svc, cfg.virac2_source_table, cfg.ra_deg, cfg.dec_deg, r)
        except Exception as exc:
            LOGGER.warning("VIRAC2 radius %.3f deg query failed: %s", r, exc)
            n = -1
        rows.append({"radius_deg": r, "n_virac2_rect": n})
    # Galactic-centre sanity check: if this returns sources, the table/query work.
    for name, ra, dec, r in [("galactic_centre_0p1", 266.41683, -29.00781, 0.10),
                             ("galactic_centre_0p5", 266.41683, -29.00781, 0.50)]:
        try:
            n = virac2_rect_count(svc, cfg.virac2_source_table, ra, dec, r)
        except Exception:
            n = -1
        rows.append({"radius_deg": r, "n_virac2_rect": n, "diagnostic_field": name})
    df = pd.DataFrame(rows)
    csv_write(df, cfg.paths()["tables"] / "VIRAC2_radius_count_diagnostic.csv")
    return df


# -------------------------------------------------------------------------
# Main analysis
# -------------------------------------------------------------------------

def load_target_gaia(cfg: Config) -> pd.DataFrame:
    # Prefer raw Gaia so membership can be recomputed over thresholds.
    candidates = [
        cfg.paths()["raw"] / "gaia_dr3_bh140_cone.csv",
        cfg.paths()["processed"] / "gaia_dr3_with_membership.csv",
    ]
    for path in candidates:
        if path.exists():
            LOGGER.info("Loading target Gaia file: %s", path)
            return pd.read_csv(path)
    raise FileNotFoundError("No Gaia target file found. Run v3 pipeline first or provide expected files.")


def evaluate_field(df: pd.DataFrame, ra0: float, dec0: float, cfg: Config,
                   field_id: str, field_kind: str) -> pd.DataFrame:
    rows = []
    for quality in parse_str_list(cfg.quality_modes):
        qmask = quality_mask(df, quality, cfg)
        for pm_sigma in parse_float_list(cfg.pm_sigmas):
            for plx_sigma in parse_float_list(cfg.parallax_sigmas):
                mem = anchored_membership(df.loc[qmask].copy(), ra0, dec0, cfg,
                                          pm_sigma=pm_sigma, parallax_sigma=plx_sigma)
                p = mem["p_mem_anchor_v4"].to_numpy(float)
                for pthr in parse_float_list(cfg.p_thresholds):
                    base_sel = np.isfinite(p) & (p >= pthr)
                    for oq in parse_float_list(cfg.outer_quantiles):
                        rows.append(summarize_selection(
                            mem, base_sel, ra0, dec0, pthr, oq, quality,
                            pm_sigma, plx_sigma, field_id, field_kind
                        ))
    return pd.DataFrame(rows)


def analyze_target_and_controls(cfg: Config, centres: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    target = load_target_gaia(cfg)
    target_results = evaluate_field(target, cfg.ra_deg, cfg.dec_deg, cfg, "BH140", "target")
    csv_write(target_results, cfg.paths()["tables"] / "BH140_threshold_stability_matrix.csv")

    ctrl_rows = []
    for _, row in centres.iterrows():
        fid = row["field_id"]
        path = cfg.paths()["control_raw"] / f"{fid}_gaia_dr3_control.csv"
        if not path.exists():
            LOGGER.warning("Missing control field file: %s", path)
            continue
        df = pd.read_csv(path)
        res = evaluate_field(df, float(row["ra_deg"]), float(row["dec_deg"]), cfg, fid, "control")
        csv_write(res, cfg.paths()["control_processed"] / f"{fid}_threshold_matrix.csv")
        ctrl_rows.append(res)
    control_results = pd.concat(ctrl_rows, ignore_index=True) if ctrl_rows else pd.DataFrame()
    if len(control_results):
        csv_write(control_results, cfg.paths()["tables"] / "BH140_matched_control_field_matrix.csv")

    # Join target grid to control grid and compute empirical control percentiles.
    summary = control_false_positive_summary(target_results, control_results)
    csv_write(summary, cfg.paths()["tables"] / "BH140_outer_anisotropy_control_summary.csv")
    return target_results, control_results, summary


def control_false_positive_summary(target_results: pd.DataFrame, control_results: pd.DataFrame) -> pd.DataFrame:
    if control_results.empty:
        target_results = target_results.copy()
        target_results["n_controls"] = 0
        target_results["fp_rate_R1"] = np.nan
        target_results["fp_rate_R2"] = np.nan
        target_results["target_R1_control_percentile"] = np.nan
        target_results["target_R2_control_percentile"] = np.nan
        target_results["claim_gate_outer"] = "candidate_no_controls"
        return target_results

    key_cols = ["p_threshold", "outer_quantile", "quality_mode", "pm_sigma_masyr", "parallax_sigma_mas"]
    rows = []
    for _, t in target_results.iterrows():
        mask = np.ones(len(control_results), dtype=bool)
        for k in key_cols:
            mask &= control_results[k].astype(str).to_numpy() == str(t[k])
        c = control_results.loc[mask]
        nctrl = c["field_id"].nunique()
        out = t.to_dict()
        out["n_controls"] = int(nctrl)
        if nctrl == 0 or not np.isfinite(t.get("rayleigh_R1", np.nan)):
            out["fp_rate_R1"] = np.nan
            out["fp_rate_R2"] = np.nan
            out["target_R1_control_percentile"] = np.nan
            out["target_R2_control_percentile"] = np.nan
            out["claim_gate_outer"] = "candidate_no_controls"
        else:
            R1c = pd.to_numeric(c["rayleigh_R1"], errors="coerce").dropna().to_numpy(float)
            R2c = pd.to_numeric(c["axial_R2"], errors="coerce").dropna().to_numpy(float)
            R1t = float(t["rayleigh_R1"])
            R2t = float(t["axial_R2"])
            fp1 = (1 + np.sum(R1c >= R1t)) / (1 + max(len(R1c), 1))
            fp2 = (1 + np.sum(R2c >= R2t)) / (1 + max(len(R2c), 1))
            pct1 = 100.0 * np.mean(R1c <= R1t) if len(R1c) else np.nan
            pct2 = 100.0 * np.mean(R2c <= R2t) if len(R2c) else np.nan
            out["fp_rate_R1"] = float(fp1)
            out["fp_rate_R2"] = float(fp2)
            out["target_R1_control_percentile"] = float(pct1)
            out["target_R2_control_percentile"] = float(pct2)
            # Conservative claim gate.
            if nctrl >= 8 and fp1 <= 0.10 and fp2 <= 0.10 and R2t >= 0.20:
                out["claim_gate_outer"] = "strong_candidate_tidal_structure"
            elif nctrl >= 8 and fp1 <= 0.10:
                out["claim_gate_outer"] = "strong_candidate_lopsided_outer_anisotropy"
            elif nctrl >= 4 and fp1 <= 0.20:
                out["claim_gate_outer"] = "candidate_outer_anisotropy_control_supported"
            else:
                out["claim_gate_outer"] = "candidate_control_sensitive"
        rows.append(out)
    return pd.DataFrame(rows)


# -------------------------------------------------------------------------
# Independent photometric/NIR status
# -------------------------------------------------------------------------

def photometric_validation_status(cfg: Config, virac2_diag: pd.DataFrame) -> pd.DataFrame:
    rows = []
    # HST/MGCS crossmatch status.
    xm_dir = cfg.paths()["processed"]
    hst_files = list(xm_dir.glob("crossmatch_gaia_mgcs_*astro*.csv"))
    hst_nmax = 0
    hst_best = ""
    for p in hst_files:
        try:
            n = len(pd.read_csv(p))
        except Exception:
            n = 0
        if n > hst_nmax:
            hst_nmax = n
            hst_best = str(p)
    rows.append({
        "layer": "HST/MGCS photometric crossmatch",
        "status": "available" if hst_nmax > 0 else "unavailable",
        "n_sources_or_matches": int(hst_nmax),
        "role": "central photometric validation; not a wide-field outer-tail confirmation",
        "file_or_note": hst_best,
    })

    # VIRAC2 direct target coverage.
    if virac2_diag is not None and len(virac2_diag):
        direct = virac2_diag[virac2_diag.get("diagnostic_field", "").fillna("").eq("")]
        n_within_2 = 0
        if len(direct):
            n_within_2 = int(direct.loc[direct["radius_deg"] <= 2.0, "n_virac2_rect"].max())
        status = "available" if n_within_2 > 0 else "no_direct_coverage_within_2deg"
        note = "Direct VIRAC2 source-layer availability at the BH140 centre."
    else:
        status = "not_tested"
        n_within_2 = -1
        note = "VIRAC2 diagnostic not run."
    rows.append({
        "layer": "VIRAC2/VVVX source table",
        "status": status,
        "n_sources_or_matches": int(n_within_2),
        "role": "independent NIR confirmation of outer anisotropy if available",
        "file_or_note": note,
    })

    # Current gate for independent outer confirmation.
    outer_status = "not_available"
    if hst_nmax > 0 and (virac2_diag is not None and len(virac2_diag)):
        outer_status = "HST_available_central_only__VIRAC2_unavailable_for_outer"
    rows.append({
        "layer": "Independent outer-anisotropy photometric confirmation",
        "status": outer_status,
        "n_sources_or_matches": np.nan,
        "role": "required before confirmed tidal-tail claim",
        "file_or_note": "Use HST for central CMD validation; use matched Gaia controls until direct NIR coverage is obtained.",
    })
    df = pd.DataFrame(rows)
    csv_write(df, cfg.paths()["tables"] / "BH140_independent_photometric_validation_status.csv")
    return df


# -------------------------------------------------------------------------
# Figures and report
# -------------------------------------------------------------------------

def make_plots(cfg: Config, target_results: pd.DataFrame, control_results: pd.DataFrame,
               summary: pd.DataFrame, virac2_diag: pd.DataFrame) -> None:
    figdir = cfg.paths()["figures"]
    figdir.mkdir(parents=True, exist_ok=True)

    # Baseline row approximately matching v3 default.
    def baseline(df):
        if df.empty:
            return df
        mask = (
            (df["p_threshold"].astype(float) == 0.90) &
            (df["outer_quantile"].astype(float) == 0.90) &
            (df["quality_mode"].astype(str) == "baseline") &
            (np.isclose(df["pm_sigma_masyr"].astype(float), cfg.pm_prior_sigma_masyr)) &
            (np.isclose(df["parallax_sigma_mas"].astype(float), cfg.parallax_prior_sigma_mas))
        )
        return df.loc[mask]

    tb = baseline(target_results)
    cb = baseline(control_results)
    if len(tb) and len(cb):
        plt.figure(figsize=(7, 5))
        plt.hist(pd.to_numeric(cb["rayleigh_R1"], errors="coerce").dropna(), bins=12, alpha=0.75, label="matched controls R1")
        plt.axvline(float(tb["rayleigh_R1"].iloc[0]), linestyle="--", label="BH140 R1")
        plt.xlabel("Rayleigh R1 (one-sided anisotropy)")
        plt.ylabel("Number of control-field grid entries")
        plt.legend()
        plt.tight_layout()
        plt.savefig(figdir / "BH140_control_R1_histogram.png", dpi=200)
        plt.close()

        plt.figure(figsize=(7, 5))
        plt.hist(pd.to_numeric(cb["axial_R2"], errors="coerce").dropna(), bins=12, alpha=0.75, label="matched controls R2")
        plt.axvline(float(tb["axial_R2"].iloc[0]), linestyle="--", label="BH140 R2")
        plt.xlabel("Axial R2 (two-sided/tail-like anisotropy)")
        plt.ylabel("Number of control-field grid entries")
        plt.legend()
        plt.tight_layout()
        plt.savefig(figdir / "BH140_control_R2_histogram.png", dpi=200)
        plt.close()

    if len(target_results):
        plt.figure(figsize=(8, 5))
        sc = plt.scatter(
            pd.to_numeric(target_results["rayleigh_R1"], errors="coerce"),
            pd.to_numeric(target_results["axial_R2"], errors="coerce"),
            c=pd.to_numeric(target_results["p_threshold"], errors="coerce"),
            s=30,
        )
        plt.xlabel("Rayleigh R1")
        plt.ylabel("Axial R2")
        plt.colorbar(sc, label="Pmem threshold")
        plt.title("BH140 threshold-stability: one-sided vs axial anisotropy")
        plt.tight_layout()
        plt.savefig(figdir / "BH140_threshold_stability_R1_R2.png", dpi=200)
        plt.close()

    if virac2_diag is not None and len(virac2_diag):
        direct = virac2_diag[virac2_diag.get("diagnostic_field", "").fillna("").eq("")]
        if len(direct):
            plt.figure(figsize=(7, 5))
            plt.plot(direct["radius_deg"], direct["n_virac2_rect"], marker="o")
            plt.yscale("symlog")
            plt.xlabel("Radius around BH140 (deg)")
            plt.ylabel("VIRAC2 rectangular-count diagnostic")
            plt.title("VIRAC2 footprint diagnostic at BH140")
            plt.tight_layout()
            plt.savefig(figdir / "BH140_VIRAC2_radius_counts.png", dpi=200)
            plt.close()


def write_json_report(cfg: Config, summary: pd.DataFrame, phot_status: pd.DataFrame) -> None:
    report = {
        "config": asdict(cfg),
        "baseline_outer_gate": None,
        "photometric_validation_status": phot_status.to_dict(orient="records"),
    }
    if len(summary):
        base = summary[
            (summary["p_threshold"].astype(float) == 0.90) &
            (summary["outer_quantile"].astype(float) == 0.90) &
            (summary["quality_mode"].astype(str) == "baseline") &
            (np.isclose(summary["pm_sigma_masyr"].astype(float), cfg.pm_prior_sigma_masyr)) &
            (np.isclose(summary["parallax_sigma_mas"].astype(float), cfg.parallax_prior_sigma_mas))
        ]
        if len(base):
            report["baseline_outer_gate"] = base.iloc[0].to_dict()
    path = cfg.paths()["tables"] / "BH140_v4_validation_report.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    LOGGER.info("Saved JSON report to %s", path)


# -------------------------------------------------------------------------
# CLI
# -------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="BH140 outer-anisotropy validation: controls + thresholds + NIR status")
    p.add_argument("--ra-deg", type=float, default=Config.ra_deg)
    p.add_argument("--dec-deg", type=float, default=Config.dec_deg)
    p.add_argument("--radius-deg", type=float, default=Config.radius_deg)
    p.add_argument("--outdir", type=str, default=Config.outdir)
    p.add_argument("--download-controls", action="store_true", help="download matched Gaia control fields")
    p.add_argument("--skip-virac2-diagnostic", action="store_true")
    p.add_argument("--analyze", action="store_true")
    p.add_argument("--n-controls", type=int, default=Config.n_controls)
    p.add_argument("--control-sep-deg", type=float, default=Config.control_sep_deg)
    p.add_argument("--p-thresholds", type=str, default=Config.p_thresholds)
    p.add_argument("--outer-quantiles", type=str, default=Config.outer_quantiles)
    p.add_argument("--pm-sigmas", type=str, default=Config.pm_sigmas)
    p.add_argument("--parallax-sigmas", type=str, default=Config.parallax_sigmas)
    p.add_argument("--quality-modes", type=str, default=Config.quality_modes)
    return p


def main(argv: Optional[List[str]] = None) -> None:
    setup_logging()
    args = build_parser().parse_args(argv)
    cfg = Config(
        ra_deg=args.ra_deg,
        dec_deg=args.dec_deg,
        radius_deg=args.radius_deg,
        outdir=args.outdir,
        n_controls=args.n_controls,
        control_sep_deg=args.control_sep_deg,
        p_thresholds=args.p_thresholds,
        outer_quantiles=args.outer_quantiles,
        pm_sigmas=args.pm_sigmas,
        parallax_sigmas=args.parallax_sigmas,
        quality_modes=args.quality_modes,
    )
    setup_dirs(cfg)

    centres = control_centres(cfg)
    if args.download_controls:
        download_control_fields(cfg, centres)

    virac2_diag = pd.DataFrame()
    if not args.skip_virac2_diagnostic:
        virac2_diag = virac2_footprint_diagnostic(cfg)

    if args.analyze:
        target_results, control_results, summary = analyze_target_and_controls(cfg, centres)
        phot_status = photometric_validation_status(cfg, virac2_diag)
        make_plots(cfg, target_results, control_results, summary, virac2_diag)
        write_json_report(cfg, summary, phot_status)
        LOGGER.info("V4 validation complete.")
        if len(summary):
            base = summary[
                (summary["p_threshold"].astype(float) == 0.90) &
                (summary["outer_quantile"].astype(float) == 0.90) &
                (summary["quality_mode"].astype(str) == "baseline") &
                (np.isclose(summary["pm_sigma_masyr"].astype(float), cfg.pm_prior_sigma_masyr)) &
                (np.isclose(summary["parallax_sigma_mas"].astype(float), cfg.parallax_prior_sigma_mas))
            ]
            if len(base):
                LOGGER.info("Baseline gate: %s", json.dumps(base.iloc[0].to_dict(), indent=2, default=str))


if __name__ == "__main__":
    main()
