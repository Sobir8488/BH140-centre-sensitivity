# WINERED crossmatch provenance

The WINERED HTML/table extraction contained 11 rows relevant to BH 140. Coordinate cleaning corrected malformed minus signs and retained seven source-level rows with valid coordinates. These seven rows were cross-matched to the Gaia-selected membership table.

The archive includes cleaned rows, the Gaia crossmatch, and a compact crossmatch summary.
