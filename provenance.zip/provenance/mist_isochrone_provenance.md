# MIST isochrone provenance

File: `data/external_derived/isochrone_bh140_mist_v1p2_acswfc_feh_m1p00_logage_10p10.csv`

- Model family: MIST v1.2
- Rotation: v/vcrit = 0.0
- Photometric system: HST ACS/WFC
- Metallicity: [Fe/H] = -1.00
- Alpha enhancement: [alpha/Fe] = 0.0 in the packaged file name
- Age: log10(age/yr) = 10.10
- Distance: 4.81 kpc
- Baseline extinction offsets used in conversion: A_F606W = 0, A_F814W = 0
- Columns retained: mass, F606W, F814W

Use this file as the baseline mass-assignment curve. Reddening and metallicity sensitivity tests are recommended for final astrophysical interpretation.
