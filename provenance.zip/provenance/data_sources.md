# Data-source provenance

## Gaia DR3
Gaia DR3 astrometric and photometric data were queried for the BH 140 field and matched control fields. The archived products include processed Gaia membership tables and filtered control-field extracts.

## HST/MGCS
HST/MGCS astro-photometric and artificial-star products are based on the MGCS release for BH 140. The package includes a filtered BH 140 artificial-star photometry extract, a derived F814W artificial-star completeness curve, and a Gaia--MGCS astro-photometric crossmatch.

## MIST
The included isochrone is derived from the MIST v1.2 non-rotating HST ACS/WFC synthetic-photometry grid. The selected baseline is `[Fe/H] = -1.00`, `log10(age/yr) = 10.10`, and a distance of 4.81 kpc. Extinction offsets were set to zero in the baseline conversion and should be varied in sensitivity tests.

## WINERED
WINERED rows were extracted from the relevant public table and cleaned for coordinate parsing. The source-level cleaned rows and Gaia crossmatch table are archived in `results/winered/`.

## VIRAC2/VVVX
A public VIRAC2 source-layer diagnostic found no usable direct source coverage at the BH 140 centre within the tested inner radii. The diagnostic table is provided only as a coverage check.
