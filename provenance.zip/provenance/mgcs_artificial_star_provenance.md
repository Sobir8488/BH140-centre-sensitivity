# MGCS artificial-star completeness provenance

The BH 140 artificial-star rows were filtered from the MGCS photometric input-output table. The filtered extract contains 583632 artificial-star photometry rows, split evenly between F606W and F814W. The completeness curve used in this package is derived in F814W by binning input magnitude and computing the recovered fraction.

Recovered definition used in the processing notebook/script:

`recovered = (mo > 0) and ((fo > 0) or (go > 0))`

The release includes:

- `data/raw_filtered/mgcs/mgcs_bh140_phot_io_lines.dat.gz`
- `data/raw_filtered/mgcs/mgcs_bh140_artificial_star_photometry_raw.csv.gz`
- `data/external_derived/mgcs_bh140_f814w_artificial_star_completeness.csv`
